'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  QrCode, 
  Search, 
  Filter, 
  Download, 
  Eye,
  Calendar,
  MapPin,
  User,
  Package,
  TrendingUp,
  AlertTriangle,
  CheckCircle
} from 'lucide-react'
import { motion } from 'framer-motion'

interface QRScan {
  id: string
  productId: string
  userId?: string
  scanDate: string
  location?: string
  scannedData: string
  phLevel?: number
  freshnessStatus?: string
  colorIndicator?: string
  guideAccessed?: string
  createdAt: string
  product: {
    id: string
    name: string
    material: string
  }
  user?: {
    id: string
    name: string
    email: string
  }
}

interface Statistics {
  totalScans: number
  uniqueUsers: number
  averagePH: number
  topGuide: string
  freshnessDistribution: Array<{ status: string; count: number }>
  colorDistribution: Array<{ color: string; count: number }>
  monthlyTrend: Array<{ month: string; count: number }>
}

export default function QRScansList() {
  const [scans, setScans] = useState<QRScan[]>([])
  const [statistics, setStatistics] = useState<Statistics | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterStatus, setFilterStatus] = useState('all')
  const [filterGuide, setFilterGuide] = useState('all')
  const [currentPage, setCurrentPage] = useState(1)
  const [selectedScan, setSelectedScan] = useState<QRScan | null>(null)

  const itemsPerPage = 10

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      const [scansResponse, statsResponse] = await Promise.all([
        fetch('/api/qr-scans'),
        fetch('/api/statistics')
      ])
      
      const scansData = await scansResponse.json()
      const statsData = await statsResponse.json()
      
      setScans(scansData)
      setStatistics(statsData)
    } catch (error) {
      console.error('Error fetching data:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const filteredScans = scans.filter(scan => {
    const matchesSearch = 
      scan.product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      scan.user?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      scan.location?.toLowerCase().includes(searchTerm.toLowerCase())
    
    const matchesStatus = filterStatus === 'all' || scan.freshnessStatus === filterStatus
    const matchesGuide = filterGuide === 'all' || scan.guideAccessed === filterGuide
    
    return matchesSearch && matchesStatus && matchesGuide
  })

  const totalPages = Math.ceil(filteredScans.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const paginatedScans = filteredScans.slice(startIndex, startIndex + itemsPerPage)

  const getFreshnessBadge = (status?: string) => {
    switch (status) {
      case 'Segar':
        return <Badge className="bg-green-100 text-green-800">🟢 Segar</Badge>
      case 'Kurang Segar':
        return <Badge className="bg-yellow-100 text-yellow-800">🟡 Kurang Segar</Badge>
      case 'Tidak Layak Konsumsi':
        return <Badge className="bg-red-100 text-red-800">🔴 Tidak Layak</Badge>
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  const getColorBadge = (color?: string) => {
    const colorMap: { [key: string]: string } = {
      'Hijau Tua': 'bg-green-600',
      'Hijau Muda': 'bg-green-400',
      'Kuning': 'bg-yellow-400',
      'Oranye': 'bg-orange-400',
      'Merah': 'bg-red-500'
    }
    
    return (
      <Badge variant="outline" className="flex items-center space-x-1">
        <div className={`w-3 h-3 rounded-full ${colorMap[color || ''] || 'bg-gray-400'}`}></div>
        <span>{color || 'Unknown'}</span>
      </Badge>
    )
  }

  const getGuideBadge = (guide?: string) => {
    const guideMap: { [key: string]: string } = {
      'color': 'Panduan Warna',
      'composting': 'Instruksi Komposting',
      'material': 'Transparansi Bahan'
    }
    
    return (
      <Badge variant="secondary" className="bg-blue-100 text-blue-800">
        {guideMap[guide || ''] || 'Unknown'}
      </Badge>
    )
  }

  const exportData = () => {
    const csvContent = [
      ['ID', 'Produk', 'Pengguna', 'Tanggal', 'Lokasi', 'pH Level', 'Status Kesegaran', 'Warna Indikator', 'Guide Diakses'],
      ...filteredScans.map(scan => [
        scan.id,
        scan.product.name,
        scan.user?.name || 'Anonymous',
        new Date(scan.scanDate).toLocaleString(),
        scan.location || 'Unknown',
        scan.phLevel || 'N/A',
        scan.freshnessStatus || 'N/A',
        scan.colorIndicator || 'N/A',
        scan.guideAccessed || 'N/A'
      ])
    ].map(row => row.join(',')).join('\n')

    const blob = new Blob([csvContent], { type: 'text/csv' })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `qr-scans-${new Date().toISOString().split('T')[0]}.csv`
    a.click()
    window.URL.revokeObjectURL(url)
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-green-800">Daftar QR Code Scans</h2>
          <p className="text-gray-600">Monitor dan analisis penggunaan QR Code oleh pengguna</p>
        </div>
        <Button onClick={exportData} className="bg-green-600 hover:bg-green-700">
          <Download className="h-4 w-4 mr-2" />
          Export Data
        </Button>
      </div>

      {/* Statistics Cards */}
      {statistics && (
        <div className="grid md:grid-cols-4 gap-4">
          <Card className="border-green-200">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Scans</p>
                  <p className="text-2xl font-bold text-green-800">{statistics.totalScans}</p>
                </div>
                <QrCode className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="border-green-200">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Unique Users</p>
                  <p className="text-2xl font-bold text-green-800">{statistics.uniqueUsers}</p>
                </div>
                <User className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="border-green-200">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Avg pH Level</p>
                  <p className="text-2xl font-bold text-green-800">{statistics.averagePH?.toFixed(1) || 'N/A'}</p>
                </div>
                <TrendingUp className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="border-green-200">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Top Guide</p>
                  <p className="text-lg font-bold text-green-800 truncate">{statistics.topGuide || 'N/A'}</p>
                </div>
                <Eye className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Filters */}
      <Card className="border-green-200">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Cari berdasarkan produk, pengguna, atau lokasi..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Status</SelectItem>
                <SelectItem value="Segar">Segar</SelectItem>
                <SelectItem value="Kurang Segar">Kurang Segar</SelectItem>
                <SelectItem value="Tidak Layak Konsumsi">Tidak Layak</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={filterGuide} onValueChange={setFilterGuide}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter Guide" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Guide</SelectItem>
                <SelectItem value="color">Panduan Warna</SelectItem>
                <SelectItem value="composting">Instruksi Komposting</SelectItem>
                <SelectItem value="material">Transparansi Bahan</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Scans Table */}
      <Card className="border-green-200">
        <CardHeader>
          <CardTitle className="text-green-800">Data QR Scans</CardTitle>
          <CardDescription>
            Menampilkan {filteredScans.length} dari {scans.length} total scans
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-green-200">
                  <th className="text-left p-3 font-semibold text-green-800">Produk</th>
                  <th className="text-left p-3 font-semibold text-green-800">Pengguna</th>
                  <th className="text-left p-3 font-semibold text-green-800">Tanggal</th>
                  <th className="text-left p-3 font-semibold text-green-800">Lokasi</th>
                  <th className="text-left p-3 font-semibold text-green-800">pH Level</th>
                  <th className="text-left p-3 font-semibold text-green-800">Status</th>
                  <th className="text-left p-3 font-semibold text-green-800">Guide</th>
                  <th className="text-left p-3 font-semibold text-green-800">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {paginatedScans.map((scan, index) => (
                  <motion.tr
                    key={scan.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                    className="border-b border-gray-100 hover:bg-green-50"
                  >
                    <td className="p-3">
                      <div>
                        <p className="font-medium text-green-800">{scan.product.name}</p>
                        <p className="text-sm text-gray-500">{scan.product.material}</p>
                      </div>
                    </td>
                    <td className="p-3">
                      <div>
                        <p className="font-medium">{scan.user?.name || 'Anonymous'}</p>
                        <p className="text-sm text-gray-500">{scan.user?.email || 'N/A'}</p>
                      </div>
                    </td>
                    <td className="p-3">
                      <div className="flex items-center space-x-2">
                        <Calendar className="h-4 w-4 text-gray-400" />
                        <span className="text-sm">
                          {new Date(scan.scanDate).toLocaleDateString()}
                        </span>
                      </div>
                    </td>
                    <td className="p-3">
                      <div className="flex items-center space-x-2">
                        <MapPin className="h-4 w-4 text-gray-400" />
                        <span className="text-sm">{scan.location || 'Unknown'}</span>
                      </div>
                    </td>
                    <td className="p-3">
                      <span className="font-medium">{scan.phLevel?.toFixed(1) || 'N/A'}</span>
                    </td>
                    <td className="p-3">
                      <div className="space-y-1">
                        {getFreshnessBadge(scan.freshnessStatus)}
                        {getColorBadge(scan.colorIndicator)}
                      </div>
                    </td>
                    <td className="p-3">
                      {getGuideBadge(scan.guideAccessed)}
                    </td>
                    <td className="p-3">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setSelectedScan(scan)}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between mt-4">
              <div className="text-sm text-gray-600">
                Menampilkan {startIndex + 1} hingga {Math.min(startIndex + itemsPerPage, filteredScans.length)} dari {filteredScans.length} scans
              </div>
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                >
                  Previous
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  disabled={currentPage === totalPages}
                >
                  Next
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Detail Modal */}
      {selectedScan && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-green-800">Detail QR Scan</CardTitle>
                  <CardDescription>ID: {selectedScan.id}</CardDescription>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedScan(null)}
                >
                  ×
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold text-green-700 mb-2">Informasi Produk</h4>
                  <p className="text-sm"><strong>Nama:</strong> {selectedScan.product.name}</p>
                  <p className="text-sm"><strong>Material:</strong> {selectedScan.product.material}</p>
                </div>
                <div>
                  <h4 className="font-semibold text-green-700 mb-2">Informasi Pengguna</h4>
                  <p className="text-sm"><strong>Nama:</strong> {selectedScan.user?.name || 'Anonymous'}</p>
                  <p className="text-sm"><strong>Email:</strong> {selectedScan.user?.email || 'N/A'}</p>
                </div>
              </div>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold text-green-700 mb-2">Waktu & Lokasi</h4>
                  <p className="text-sm"><strong>Tanggal:</strong> {new Date(selectedScan.scanDate).toLocaleString()}</p>
                  <p className="text-sm"><strong>Lokasi:</strong> {selectedScan.location || 'Unknown'}</p>
                </div>
                <div>
                  <h4 className="font-semibold text-green-700 mb-2">Deteksi Kesegaran</h4>
                  <p className="text-sm"><strong>pH Level:</strong> {selectedScan.phLevel || 'N/A'}</p>
                  <p className="text-sm"><strong>Status:</strong> {selectedScan.freshnessStatus || 'N/A'}</p>
                  <p className="text-sm"><strong>Warna:</strong> {selectedScan.colorIndicator || 'N/A'}</p>
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold text-green-700 mb-2">Data Scan</h4>
                <pre className="text-xs bg-gray-100 p-3 rounded-lg overflow-x-auto">
                  {JSON.stringify(JSON.parse(selectedScan.scannedData), null, 2)}
                </pre>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}