import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const reports = await db.compostingReport.findMany({
      include: {
        user: true,
        product: true
      },
      orderBy: {
        createdAt: 'desc'
      }
    })
    
    return NextResponse.json(reports)
  } catch (error) {
    console.error('Error fetching composting reports:', error)
    return NextResponse.json(
      { error: 'Failed to fetch composting reports' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, productId, method, status, notes, imageUrl } = body

    if (!method) {
      return NextResponse.json(
        { error: 'Method is required' },
        { status: 400 }
      )
    }

    const report = await db.compostingReport.create({
      data: {
        userId: userId || null,
        productId: productId || null,
        method,
        status: status || 'in_progress',
        notes: notes || null,
        imageUrl: imageUrl || null
      }
    })

    return NextResponse.json(report, { status: 201 })
  } catch (error) {
    console.error('Error creating composting report:', error)
    return NextResponse.json(
      { error: 'Failed to create composting report' },
      { status: 500 }
    )
  }
}