import { NextRequest, NextResponse } from 'next/server'
import { emailService } from '@/lib/email'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { type, recipient, data } = body

    let result = false

    switch (type) {
      case 'welcome':
        result = await emailService.sendWelcomeEmail(
          recipient,
          data.userName
        )
        break
      
      case 'qr-scan':
        result = await emailService.sendQRScanNotification(
          recipient,
          data.productName,
          new Date(data.scanDate)
        )
        break
      
      case 'admin':
        result = await emailService.sendAdminNotification(
          data.subject,
          data.message
        )
        break
      
      default:
        return NextResponse.json(
          { error: 'Invalid notification type' },
          { status: 400 }
        )
    }

    if (result) {
      return NextResponse.json({ 
        success: true, 
        message: 'Email sent successfully' 
      })
    } else {
      return NextResponse.json(
        { error: 'Failed to send email' },
        { status: 500 }
      )
    }
  } catch (error) {
    console.error('Error sending notification:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}