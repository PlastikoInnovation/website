'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Slider } from '@/components/ui/slider'
import { QrCode, Droplets, AlertTriangle, CheckCircle, Info } from 'lucide-react'
import { motion } from 'framer-motion'

interface ColorState {
  name: string
  color: string
  bgColor: string
  description: string
  phRange: string
  freshness: string
  recommendation: string
  icon: React.ReactNode
}

const colorStates: ColorState[] = [
  {
    name: 'Hijau Tua',
    color: 'text-green-800',
    bgColor: 'bg-green-600',
    description: 'Makanan sangat segar dan aman dikonsumsi',
    phRange: 'pH 6.5 - 7.0',
    freshness: 'Sangat Segar',
    recommendation: 'Sangat baik untuk dikonsumsi. Nutrisi masih terjaga dengan sempurna.',
    icon: <CheckCircle className="h-6 w-6" />
  },
  {
    name: 'Hijau Muda',
    color: 'text-green-600',
    bgColor: 'bg-green-400',
    description: 'Makanan segar dan layak konsumsi',
    phRange: 'pH 7.0 - 7.5',
    freshness: 'Segar',
    recommendation: 'Baik untuk dikonsumsi. Kualitas masih terjaga dengan baik.',
    icon: <CheckCircle className="h-6 w-6" />
  },
  {
    name: 'Kuning',
    color: 'text-yellow-600',
    bgColor: 'bg-yellow-400',
    description: 'Makanan mulai berkurang kesegarannya',
    phRange: 'pH 7.5 - 8.0',
    freshness: 'Kurang Segar',
    recommendation: 'Masih dapat dikonsumsi, namun sebaiknya segera diolah atau disimpan dengan benar.',
    icon: <Info className="h-6 w-6" />
  },
  {
    name: 'Oranye',
    color: 'text-orange-600',
    bgColor: 'bg-orange-400',
    description: 'Makanan tidak segar, perlu hati-hati',
    phRange: 'pH 8.0 - 8.5',
    freshness: 'Tidak Segar',
    recommendation: 'Tidak disarankan dikonsumsi mentah. Perlu pemeriksaan lebih lanjut.',
    icon: <AlertTriangle className="h-6 w-6" />
  },
  {
    name: 'Merah',
    color: 'text-red-600',
    bgColor: 'bg-red-500',
    description: 'Makanan tidak layak konsumsi',
    phRange: 'pH > 8.5',
    freshness: 'Berbahaya',
    recommendation: 'JANGAN DIKONSUMSI! Makanan sudah terkontaminasi dan berbahaya bagi kesehatan.',
    icon: <AlertTriangle className="h-6 w-6" />
  }
]

export default function ColorGuide() {
  const [phLevel, setPhLevel] = useState([7.0])
  const [selectedState, setSelectedState] = useState<ColorState>(colorStates[1])
  const [isScanning, setIsScanning] = useState(false)

  // Calculate color state based on pH level
  const getColorState = (ph: number): ColorState => {
    if (ph <= 7.0) return colorStates[0]
    if (ph <= 7.5) return colorStates[1]
    if (ph <= 8.0) return colorStates[2]
    if (ph <= 8.5) return colorStates[3]
    return colorStates[4]
  }

  const handlePhChange = (value: number[]) => {
    setPhLevel(value)
    setSelectedState(getColorState(value[0]))
  }

  const handleQRScan = () => {
    setIsScanning(true)
    setTimeout(() => {
      setIsScanning(false)
      // Simulate getting pH data from QR scan
      const randomPh = 6.5 + Math.random() * 3
      setPhLevel([randomPh])
      setSelectedState(getColorState(randomPh))
    }, 2000)
  }

  const currentColorState = getColorState(phLevel[0])

  return (
    <div className="space-y-8">
      {/* Interactive Color Simulation */}
      <Card className="border-green-200 overflow-hidden">
        <CardHeader>
          <CardTitle className="text-green-800 flex items-center">
            <Droplets className="h-5 w-5 mr-2" />
            Panduan Warna Kemasan Interaktif
          </CardTitle>
          <CardDescription>
            Simulasi perubahan warna kemasan berdasarkan pH dan kondisi makanan
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Color Display */}
          <div className="flex justify-center">
            <motion.div
              key={currentColorState.name}
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.3 }}
              className="relative"
            >
              <div className={`w-48 h-48 ${currentColorState.bgColor} rounded-3xl shadow-2xl flex items-center justify-center relative overflow-hidden`}>
                <div className="absolute inset-0 bg-white bg-opacity-20"></div>
                <div className="relative text-white text-center">
                  <div className="text-6xl font-bold mb-2">{phLevel[0].toFixed(1)}</div>
                  <div className="text-lg font-semibold">pH Level</div>
                  <div className="text-sm mt-2">{currentColorState.name}</div>
                </div>
              </div>
              <motion.div
                animate={{ 
                  boxShadow: [
                    "0 0 0 0 rgba(34, 197, 94, 0.7)",
                    "0 0 0 20px rgba(34, 197, 94, 0)",
                    "0 0 0 0 rgba(34, 197, 94, 0)"
                  ]
                }}
                transition={{ duration: 2, repeat: Infinity }}
                className="absolute inset-0 rounded-3xl"
              />
            </motion.div>
          </div>

          {/* pH Slider */}
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-gray-700">Atur pH Level</label>
              <Badge variant="outline" className="border-green-600 text-green-600">
                {currentColorState.freshness}
              </Badge>
            </div>
            <Slider
              value={phLevel}
              onValueChange={handlePhChange}
              max={10}
              min={6}
              step={0.1}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-gray-500">
              <span>6.0 (Asam)</span>
              <span>8.0 (Netral)</span>
              <span>10.0 (Basa)</span>
            </div>
          </div>

          {/* QR Scan Button */}
          <div className="text-center">
            <Button 
              onClick={handleQRScan}
              className="bg-green-600 hover:bg-green-700 text-white"
              disabled={isScanning}
            >
              {isScanning ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Mendeteksi pH...
                </>
              ) : (
                <>
                  <QrCode className="h-4 w-4 mr-2" />
                  Scan QR Code untuk Info Detail
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Color States Information */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {colorStates.map((state, index) => (
          <motion.div
            key={state.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <Card className={`border-2 transition-all duration-300 ${
              currentColorState.name === state.name 
                ? 'border-green-500 shadow-lg' 
                : 'border-gray-200 hover:border-green-300'
            }`}>
              <CardContent className="p-4">
                <div className="flex items-center space-x-3 mb-3">
                  <div className={`w-12 h-12 ${state.bgColor} rounded-full flex items-center justify-center text-white`}>
                    {state.icon}
                  </div>
                  <div>
                    <h3 className={`font-semibold ${state.color}`}>{state.name}</h3>
                    <p className="text-xs text-gray-500">{state.phRange}</p>
                  </div>
                </div>
                <p className="text-sm text-gray-600 mb-2">{state.description}</p>
                <Badge variant="secondary" className="text-xs">
                  {state.freshness}
                </Badge>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Detailed Information */}
      <Card className="border-green-200">
        <CardHeader>
          <CardTitle className="text-green-800">Informasi Detail</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <h4 className="font-semibold text-green-700 mb-2">Status Kesegaran</h4>
              <p className="text-gray-600">{currentColorState.description}</p>
            </div>
            <div>
              <h4 className="font-semibold text-green-700 mb-2">Rekomendasi</h4>
              <p className="text-gray-600">{currentColorState.recommendation}</p>
            </div>
            <div className="bg-green-50 rounded-lg p-4">
              <h4 className="font-semibold text-green-700 mb-2">Cara Kerja Teknologi</h4>
              <p className="text-sm text-gray-600">
                Kemasan PlastiKo menggunakan sensor pH alami yang berubah warna sesuai dengan tingkat keasaman makanan. 
                Semakin tinggi pH, semakin basa makanan tersebut, yang menunjukkan penurunan kesegaran. 
                Teknologi ini membantu konsumen membuat keputusan yang lebih baik tentang keamanan pangan.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}