'use client'

import { useState, useRef, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { QrCode, Camera, CameraOff, X, CheckCircle, Info } from 'lucide-react'
import { motion } from 'framer-motion'

interface QRScannerProps {
  onClose: () => void
  onScanSuccess: (data: any) => void
}

export default function QRScanner({ onClose, onScanSuccess }: QRScannerProps) {
  const [isScanning, setIsScanning] = useState(false)
  const [scanResult, setScanResult] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const streamRef = useRef<MediaStream | null>(null)

  const startScanning = async () => {
    try {
      setIsScanning(true)
      setError(null)
      
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      })
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        streamRef.current = stream
      }
      
      // Simulate QR scan detection with food freshness data
      setTimeout(() => {
        const mockPhLevel = 6.5 + Math.random() * 3 // Random pH between 6.5 and 9.5
        const mockScanData = {
          productId: '1',
          productName: 'PlastiKo Food Container',
          phLevel: mockPhLevel,
          freshnessStatus: mockPhLevel <= 7.5 ? 'Segar' : mockPhLevel <= 8.5 ? 'Kurang Segar' : 'Tidak Layak Konsumsi',
          colorIndicator: mockPhLevel <= 7.0 ? 'Hijau Tua' : mockPhLevel <= 7.5 ? 'Hijau Muda' : mockPhLevel <= 8.0 ? 'Kuning' : mockPhLevel <= 8.5 ? 'Oranye' : 'Merah',
          scannedData: {
            colorGuide: `${mockPhLevel <= 7.0 ? 'Hijau Tua' : mockPhLevel <= 7.5 ? 'Hijau Muda' : mockPhLevel <= 8.0 ? 'Kuning' : mockPhLevel <= 8.5 ? 'Oranye' : 'Merah'} - ${mockPhLevel <= 7.5 ? 'Makanan segar dan aman' : mockPhLevel <= 8.5 ? 'Makanan mulai basi, perlu hati-hati' : 'Makanan tidak layak konsumsi'}`,
            compostingInstructions: 'Place in compost bin with organic waste. Will decompose in 3-6 months.',
            materialTransparency: '100% PLA (Polylactic Acid) from renewable corn starch',
            carbonFootprint: '75% lower carbon footprint than traditional plastic',
            recyclingInfo: 'Can be composted at home or in industrial facilities',
            foodSafetyInfo: {
              currentPH: mockPhLevel.toFixed(1),
              recommendedPH: '6.5 - 7.5',
              safetyLevel: mockPhLevel <= 7.5 ? 'Safe for consumption' : mockPhLevel <= 8.5 ? 'Consume with caution' : 'Not safe for consumption',
              recommendations: mockPhLevel <= 7.5 ? 'Food is fresh and safe to eat' : mockPhLevel <= 8.5 ? 'Food should be consumed immediately or cooked thoroughly' : 'Food should be discarded immediately'
            }
          },
          scanDate: new Date().toISOString(),
          location: 'Jakarta, Indonesia'
        }
        
        handleScanSuccess(mockScanData)
      }, 3000)
      
    } catch (err) {
      setError('Unable to access camera. Please check permissions.')
      setIsScanning(false)
    }
  }

  const stopScanning = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop())
      streamRef.current = null
    }
    setIsScanning(false)
  }

  const handleScanSuccess = (data: any) => {
    setScanResult(data)
    stopScanning()
    
    // Send notification email (optional)
    if (data.userEmail) {
      fetch('/api/notifications', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          type: 'qr-scan',
          recipient: data.userEmail,
          data: {
            productName: data.productName,
            scanDate: data.scanDate
          }
        })
      }).catch(console.error)
    }
    
    onScanSuccess(data)
  }

  const handleClose = () => {
    stopScanning()
    onClose()
  }

  useEffect(() => {
    return () => {
      stopScanning()
    }
  }, [])

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
    >
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="flex items-center text-green-800">
              <QrCode className="h-5 w-5 mr-2" />
              QR Code Scanner
            </CardTitle>
            <CardDescription>
              Scan QR Code pada produk PlastiKo untuk melihat informasi detail
            </CardDescription>
          </div>
          <Button variant="ghost" size="sm" onClick={handleClose}>
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {!scanResult ? (
            <div className="space-y-4">
              <div className="relative bg-black rounded-lg overflow-hidden" style={{ aspectRatio: '16/9' }}>
                {isScanning ? (
                  <>
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-48 h-48 border-2 border-green-400 rounded-lg relative">
                        <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-green-500 rounded-tl-lg"></div>
                        <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-green-500 rounded-tr-lg"></div>
                        <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-green-500 rounded-bl-lg"></div>
                        <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-green-500 rounded-br-lg"></div>
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="animate-pulse">
                            <QrCode className="h-12 w-12 text-green-400" />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="absolute bottom-4 left-4 right-4">
                      <div className="bg-black bg-opacity-50 text-white text-center py-2 px-4 rounded-lg">
                        <p className="text-sm">Mendekatkan QR Code ke area scan</p>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="flex items-center justify-center h-full">
                    <div className="text-center">
                      <Camera className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-400">Kamera tidak aktif</p>
                    </div>
                  </div>
                )}
              </div>
              
              {error && (
                <div className="bg-red-50 border border-red-200 text-red-700 p-3 rounded-lg">
                  <p className="text-sm">{error}</p>
                </div>
              )}
              
              <div className="flex justify-center space-x-4">
                {!isScanning ? (
                  <Button 
                    onClick={startScanning}
                    className="bg-green-600 hover:bg-green-700 text-white"
                  >
                    <Camera className="h-4 w-4 mr-2" />
                    Mulai Scan
                  </Button>
                ) : (
                  <Button 
                    onClick={stopScanning}
                    variant="outline"
                    className="border-red-600 text-red-600 hover:bg-red-50"
                  >
                    <CameraOff className="h-4 w-4 mr-2" />
                    Stop Scan
                  </Button>
                )}
              </div>
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
                  <CheckCircle className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold text-green-800">Scan Berhasil!</h3>
                <p className="text-gray-600">Produk PlastiKo terdeteksi</p>
              </div>
              
              <Card className="border-green-200">
                <CardHeader>
                  <CardTitle className="text-green-800 flex items-center justify-between">
                    {scanResult.productName}
                    <Badge 
                      variant="secondary" 
                      className={
                        scanResult.phLevel <= 7.5 
                          ? 'bg-green-100 text-green-800' 
                          : scanResult.phLevel <= 8.5 
                            ? 'bg-yellow-100 text-yellow-800' 
                            : 'bg-red-100 text-red-800'
                      }
                    >
                      {scanResult.freshnessStatus}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Food Safety Alert */}
                  <div className={`p-4 rounded-lg ${
                    scanResult.phLevel <= 7.5 
                      ? 'bg-green-50 border border-green-200' 
                      : scanResult.phLevel <= 8.5 
                        ? 'bg-yellow-50 border border-yellow-200' 
                        : 'bg-red-50 border border-red-200'
                  }`}>
                    <div className="flex items-center space-x-2 mb-2">
                      <div className={`w-4 h-4 rounded-full ${
                        scanResult.phLevel <= 7.5 
                          ? 'bg-green-500' 
                          : scanResult.phLevel <= 8.5 
                            ? 'bg-yellow-500' 
                            : 'bg-red-500'
                      }`}></div>
                      <h4 className={`font-semibold ${
                        scanResult.phLevel <= 7.5 
                          ? 'text-green-800' 
                          : scanResult.phLevel <= 8.5 
                            ? 'text-yellow-800' 
                            : 'text-red-800'
                      }`}>
                        Deteksi Kesegaran Makanan
                      </h4>
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="font-medium">pH Level:</span>
                        <span className={`ml-2 font-bold ${
                          scanResult.phLevel <= 7.5 
                            ? 'text-green-700' 
                            : scanResult.phLevel <= 8.5 
                              ? 'text-yellow-700' 
                              : 'text-red-700'
                        }`}>
                          {scanResult.scannedData.foodSafetyInfo.currentPH}
                        </span>
                      </div>
                      <div>
                        <span className="font-medium">Warna Indikator:</span>
                        <span className="ml-2 font-bold">{scanResult.colorIndicator}</span>
                      </div>
                    </div>
                    <p className={`text-sm mt-2 ${
                      scanResult.phLevel <= 7.5 
                        ? 'text-green-700' 
                        : scanResult.phLevel <= 8.5 
                          ? 'text-yellow-700' 
                          : 'text-red-700'
                    }`}>
                      {scanResult.scannedData.foodSafetyInfo.recommendations}
                    </p>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-semibold text-green-700 mb-2">Panduan Warna</h4>
                      <p className="text-sm text-gray-600">{scanResult.scannedData.colorGuide}</p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-green-700 mb-2">Instruksi Komposting</h4>
                      <p className="text-sm text-gray-600">{scanResult.scannedData.compostingInstructions}</p>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-green-700 mb-2">Transparansi Bahan</h4>
                    <p className="text-sm text-gray-600">{scanResult.scannedData.materialTransparency}</p>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-green-700 mb-2">Jejak Karbon</h4>
                    <p className="text-sm text-gray-600">{scanResult.scannedData.carbonFootprint}</p>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-green-700 mb-2">Informasi Daur Ulang</h4>
                    <p className="text-sm text-gray-600">{scanResult.scannedData.recyclingInfo}</p>
                  </div>
                  
                  <div className="flex items-center justify-between pt-4 border-t border-green-200">
                    <div className="text-sm text-gray-500">
                      <p>Scan Date: {new Date(scanResult.scanDate).toLocaleString()}</p>
                      <p>Location: {scanResult.location}</p>
                    </div>
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                      Verified Product
                    </Badge>
                  </div>
                </CardContent>
              </Card>
              
              <div className="flex justify-center space-x-4">
                <Button 
                  onClick={() => {
                    setScanResult(null)
                    startScanning()
                  }}
                  variant="outline"
                  className="border-green-600 text-green-600 hover:bg-green-50"
                >
                  Scan Lagi
                </Button>
                <Button 
                  onClick={handleClose}
                  className="bg-green-600 hover:bg-green-700 text-white"
                >
                  Selesai
                </Button>
              </div>
            </motion.div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  )
}