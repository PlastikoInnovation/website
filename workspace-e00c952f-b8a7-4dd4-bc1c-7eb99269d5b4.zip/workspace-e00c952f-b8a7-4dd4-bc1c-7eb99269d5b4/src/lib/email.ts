import nodemailer from 'nodemailer'

interface EmailOptions {
  to: string
  subject: string
  html: string
  text?: string
}

class EmailService {
  private transporter: nodemailer.Transporter

  constructor() {
    // Configure transporter (using Gmail for development)
    this.transporter = nodemailer.createTransporter({
      host: process.env.SMTP_HOST || 'smtp.gmail.com',
      port: parseInt(process.env.SMTP_PORT || '587'),
      secure: false,
      auth: {
        user: process.env.SMTP_USER || 'your-email@gmail.com',
        pass: process.env.SMTP_PASS || 'your-app-password'
      }
    })
  }

  async sendEmail(options: EmailOptions): Promise<boolean> {
    try {
      const mailOptions = {
        from: process.env.SMTP_FROM || 'PlastiKo <noreply@plastiko.id>',
        to: options.to,
        subject: options.subject,
        html: options.html,
        text: options.text || this.htmlToText(options.html)
      }

      const result = await this.transporter.sendMail(mailOptions)
      console.log('Email sent successfully:', result.messageId)
      return true
    } catch (error) {
      console.error('Error sending email:', error)
      return false
    }
  }

  async sendWelcomeEmail(userEmail: string, userName: string): Promise<boolean> {
    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Selamat Datang di PlastiKo</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #16a34a; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background: #f0fdf4; }
          .footer { background: #16a34a; color: white; padding: 20px; text-align: center; }
          .button { display: inline-block; background: #16a34a; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; margin: 20px 0; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Selamat Datang di PlastiKo!</h1>
            <p>Solusi Bioplastik Berkelanjutan</p>
          </div>
          <div class="content">
            <p>Hai ${userName},</p>
            <p>Terima kasih telah bergabung dengan PlastiKo! Kami sangat senang menyambut Anda dalam perjalanan menuju masa depan yang lebih hijau.</p>
            <p>Dengan PlastiKo, Anda telah memilih solusi kemasan yang:</p>
            <ul>
              <li>100% biodegradable</li>
              <li>Terbuat dari bahan terbarukan</li>
              <li>Ramah lingkungan</li>
              <li>Dapat dilacak dengan QR Code</li>
            </ul>
            <p>Jelajahi produk kami dan mulai perjalanan hijau Anda hari ini!</p>
            <div style="text-align: center;">
              <a href="https://plastiko.id" class="button">Jelajahi Produk</a>
            </div>
          </div>
          <div class="footer">
            <p>&copy; 2024 PlastiKo. All rights reserved.</p>
            <p>Jl. Hijau No. 1, Jakarta, Indonesia</p>
          </div>
        </div>
      </body>
      </html>
    `

    return this.sendEmail({
      to: userEmail,
      subject: 'Selamat Datang di PlastiKo - Mulai Perjalanan Hijau Anda!',
      html
    })
  }

  async sendQRScanNotification(userEmail: string, productName: string, scanDate: Date): Promise<boolean> {
    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>QR Code PlastiKo Terdeteksi</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #16a34a; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background: #f0fdf4; }
          .footer { background: #16a34a; color: white; padding: 20px; text-align: center; }
          .info-box { background: white; padding: 15px; border-left: 4px solid #16a34a; margin: 15px 0; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>QR Code PlastiKo Terdeteksi!</h1>
            <p>Produk Anda berhasil dipindai</p>
          </div>
          <div class="content">
            <p>Terima kasih telah menggunakan QR Code PlastiKo!</p>
            <div class="info-box">
              <h3>Detail Scan:</h3>
              <p><strong>Produk:</strong> ${productName}</p>
              <p><strong>Waktu Scan:</strong> ${scanDate.toLocaleString('id-ID')}</p>
            </div>
            <p>Dengan memindai QR Code ini, Anda telah:</p>
            <ul>
              <li>Melacak informasi produk</li>
              <li>Mengetahui panduan komposting</li>
              <li>Membantu kami memantau penggunaan produk</li>
            </ul>
            <p>Bersama kita bisa membuat perubahan positif untuk lingkungan!</p>
          </div>
          <div class="footer">
            <p>&copy; 2024 PlastiKo. All rights reserved.</p>
            <p>Jl. Hijau No. 1, Jakarta, Indonesia</p>
          </div>
        </div>
      </body>
      </html>
    `

    return this.sendEmail({
      to: userEmail,
      subject: `QR Code ${productName} Berhasil Dipindai`,
      html
    })
  }

  async sendAdminNotification(subject: string, message: string): Promise<boolean> {
    const adminEmail = process.env.ADMIN_EMAIL || 'admin@plastiko.id'
    
    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Notifikasi Admin PlastiKo</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #dc2626; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background: #fef2f2; }
          .alert { background: #fee2e2; border: 1px solid #fecaca; padding: 15px; border-radius: 4px; margin: 15px 0; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Notifikasi Sistem PlastiKo</h1>
          </div>
          <div class="content">
            <div class="alert">
              <h3>${subject}</h3>
              <p>${message}</p>
              <p><small>Waktu: ${new Date().toLocaleString('id-ID')}</small></p>
            </div>
            <p>Silakan periksa dashboard admin untuk informasi lebih lanjut.</p>
          </div>
        </div>
      </body>
      </html>
    `

    return this.sendEmail({
      to: adminEmail,
      subject: `[PlastiKo Admin] ${subject}`,
      html
    })
  }

  private htmlToText(html: string): string {
    return html
      .replace(/<[^>]*>/g, '')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'")
  }
}

export const emailService = new EmailService()