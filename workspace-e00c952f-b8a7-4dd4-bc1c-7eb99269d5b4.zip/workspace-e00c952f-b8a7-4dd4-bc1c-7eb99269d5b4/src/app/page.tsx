'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Leaf, Package, Recycle, Smartphone, QrCode, ChevronRight, Users, TrendingUp, Globe, Mail, Phone, MapPin, Facebook, Instagram, Linkedin, Twitter, ExternalLink } from 'lucide-react'
import { motion } from 'framer-motion'
import QRScanner from '@/components/QRScanner'
import ColorChangeAnimation from '@/components/ColorChangeAnimation'
import ColorGuide from '@/components/ColorGuide'
import CompostingGuide from '@/components/CompostingGuide'

export default function Home() {
  const [activeTab, setActiveTab] = useState('products')
  const [showQRScanner, setShowQRScanner] = useState(false)

  const products = [
    {
      id: 1,
      name: 'PlastiKo Food Container',
      description: 'Wadah makanan biodegradable yang ramah lingkungan',
      price: 25000,
      material: 'PLA (Polylactic Acid)',
      advantages: '100% biodegradable, food safe, compostable',
      image: '/api/placeholder/300/200'
    },
    {
      id: 2,
      name: 'PlastiKo Shopping Bag',
      description: 'Tas belanja dari bahan terbarukan',
      price: 15000,
      material: 'Corn Starch Bioplastic',
      advantages: 'Water resistant, durable, biodegradable',
      image: '/api/placeholder/300/200'
    },
    {
      id: 3,
      name: 'PlastiKo Cutlery Set',
      description: 'Set peralatan makan sekali pakai yang ramah lingkungan',
      price: 35000,
      material: 'CPLA (Crystallized PLA)',
      advantages: 'Heat resistant, sturdy, compostable',
      image: '/api/placeholder/300/200'
    }
  ]

  const handleQRScan = () => {
    setShowQRScanner(true)
  }

  const handleScanSuccess = (data: any) => {
    console.log('QR Scan Result:', data)
    // Here you can save the scan data to the backend
    // fetch('/api/qr-scans', { method: 'POST', body: JSON.stringify(data) })
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-green-100">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Leaf className="h-8 w-8 text-green-600" />
              <span className="text-2xl font-bold text-green-800">PlastiKo</span>
            </div>
            <nav className="hidden md:flex items-center space-x-6">
              <Button variant="ghost" className="text-green-700 hover:text-green-900">Beranda</Button>
              <Button variant="ghost" className="text-green-700 hover:text-green-900">Produk</Button>
              <Button variant="ghost" className="text-green-700 hover:text-green-900">Tentang</Button>
              <Button variant="ghost" className="text-green-700 hover:text-green-900">Kontak</Button>
              <a href="/admin">
                <Button className="bg-green-600 hover:bg-green-700 text-white">Masuk Admin</Button>
              </a>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center bg-green-100 text-green-800 px-4 py-2 rounded-full mb-6">
              <Leaf className="h-4 w-4 mr-2" />
              <span className="text-sm font-semibold">100% Biodegradable Smart Packaging</span>
            </div>
            <h1 className="text-4xl md:text-6xl font-bold text-green-800 mb-6 leading-tight">
              PlastiKo – Bioplastik Ramah Lingkungan yang Dapat Terurai
            </h1>
            <p className="text-lg text-gray-700 mb-8 leading-relaxed">
              Inovasi kemasan berbasis bioplastik yang menunjukkan perubahan warna untuk mendeteksi kesegaran makanan dan mudah terurai setelah digunakan. Teknologi cerdas untuk masa depan yang berkelanjutan.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <Button 
                size="lg" 
                className="bg-green-600 hover:bg-green-700 text-white"
                onClick={() => setActiveTab('guide')}
              >
                Pelajari Lebih Lanjut
                <ChevronRight className="ml-2 h-5 w-5" />
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                className="border-green-600 text-green-600 hover:bg-green-50"
                onClick={handleQRScan}
              >
                <QrCode className="mr-2 h-5 w-5" />
                Scan QR Code
              </Button>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">100%</div>
                <div className="text-sm text-gray-600">Biodegradable</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">3-6</div>
                <div className="text-sm text-gray-600">Bulan Terurai</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">0%</div>
                <div className="text-sm text-gray-600">Plastic Waste</div>
              </div>
            </div>
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative"
          >
            <div className="relative">
              {/* Main packaging image */}
              <div className="bg-gradient-to-br from-green-100 to-green-200 rounded-3xl p-8 shadow-2xl">
                <div className="bg-white rounded-2xl p-6 shadow-lg">
                  <div className="relative">
                    <Package className="h-24 w-24 text-green-600 mx-auto mb-4" />
                    <div className="absolute -top-2 -right-2 w-8 h-8 bg-red-500 rounded-full animate-pulse"></div>
                    <div className="absolute -bottom-2 -left-2 w-6 h-6 bg-green-500 rounded-full animate-pulse"></div>
                  </div>
                  <h3 className="text-xl font-semibold text-green-800 text-center mb-2">Smart Packaging</h3>
                  <p className="text-gray-600 text-center text-sm">Deteksi kesegaran makanan secara visual</p>
                </div>
              </div>
              
              {/* Floating elements */}
              <motion.div
                animate={{ y: [-10, 10, -10] }}
                transition={{ duration: 3, repeat: Infinity }}
                className="absolute -top-4 -right-4 bg-white rounded-xl p-3 shadow-lg"
              >
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="text-xs font-medium text-green-800">Segar</span>
                </div>
              </motion.div>
              
              <motion.div
                animate={{ y: [10, -10, 10] }}
                transition={{ duration: 3, repeat: Infinity, delay: 1 }}
                className="absolute -bottom-4 -left-4 bg-white rounded-xl p-3 shadow-lg"
              >
                <div className="flex items-center space-x-2">
                  <Recycle className="h-4 w-4 text-green-600" />
                  <span className="text-xs font-medium text-green-800">Eco-Friendly</span>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-green-800 mb-4">Mengapa Memilih PlastiKo?</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Kami berkomitmen untuk menyediakan solusi kemasan yang ramah lingkungan 
            dengan inovasi terkini dalam teknologi bioplastik.
          </p>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          <motion.div whileHover={{ scale: 1.05 }} transition={{ duration: 0.2 }}>
            <Card className="border-green-200 hover:shadow-lg transition-shadow">
              <CardHeader className="text-center">
                <Recycle className="h-12 w-12 text-green-600 mx-auto mb-2" />
                <CardTitle className="text-green-800">100% Daur Ulang</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center">
                  Semua produk kami dapat didaur ulang dan terurai secara alami 
                  tanpa meninggalkan residu berbahaya.
                </p>
              </CardContent>
            </Card>
          </motion.div>
          <motion.div whileHover={{ scale: 1.05 }} transition={{ duration: 0.2 }}>
            <Card className="border-green-200 hover:shadow-lg transition-shadow">
              <CardHeader className="text-center">
                <Leaf className="h-12 w-12 text-green-600 mx-auto mb-2" />
                <CardTitle className="text-green-800">Bahan Terbarukan</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center">
                  Terbuat dari sumber daya terbarukan seperti jagung, tebu, 
                  dan pati sayuran.
                </p>
              </CardContent>
            </Card>
          </motion.div>
          <motion.div whileHover={{ scale: 1.05 }} transition={{ duration: 0.2 }}>
            <Card className="border-green-200 hover:shadow-lg transition-shadow">
              <CardHeader className="text-center">
                <Smartphone className="h-12 w-12 text-green-600 mx-auto mb-2" />
                <CardTitle className="text-green-800">Track & Trace</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center">
                  Pantai proses daur ulang produk Anda dengan QR Code 
                  yang terintegrasi dengan sistem kami.
                </p>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </section>

      {/* Products Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-green-800 mb-4">Produk PlastiKo</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Jelajahi berbagai produk bioplastik kami yang dirancang untuk 
            memenuhi kebutuhan berbagai industri.
          </p>
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5 bg-green-100">
            <TabsTrigger value="products" className="data-[state=active]:bg-green-600 data-[state=active]:text-white">
              Produk
            </TabsTrigger>
            <TabsTrigger value="color-guide" className="data-[state=active]:bg-green-600 data-[state=active]:text-white">
              Panduan Warna
            </TabsTrigger>
            <TabsTrigger value="guide" className="data-[state=active]:bg-green-600 data-[state=active]:text-white">
              Panduan Penggunaan
            </TabsTrigger>
            <TabsTrigger value="animation" className="data-[state=active]:bg-green-600 data-[state=active]:text-white">
              Animasi Warna
            </TabsTrigger>
            <TabsTrigger value="tracking" className="data-[state=active]:bg-green-600 data-[state=active]:text-white">
              Pelacakan
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="products" className="mt-8">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map((product, index) => (
                <motion.div 
                  key={product.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                >
                  <Card className="border-green-200 hover:shadow-lg transition-all duration-300 overflow-hidden group">
                    <div className="h-48 bg-gradient-to-br from-green-100 to-green-200 flex items-center justify-center">
                      <Package className="h-16 w-16 text-green-600 group-hover:scale-110 transition-transform" />
                    </div>
                    <CardHeader>
                      <CardTitle className="text-green-800">{product.name}</CardTitle>
                      <CardDescription>{product.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">Harga:</span>
                          <span className="font-semibold text-green-700">Rp {product.price.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">Material:</span>
                          <Badge variant="secondary" className="bg-green-100 text-green-800">
                            {product.material}
                          </Badge>
                        </div>
                        <Button className="w-full bg-green-600 hover:bg-green-700 text-white mt-4">
                          Lihat Detail
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="features" className="mt-8">
            <div className="grid md:grid-cols-2 gap-8">
              <Card className="border-green-200">
                <CardHeader>
                  <CardTitle className="text-green-800 flex items-center">
                    <QrCode className="mr-2 h-5 w-5" />
                    QR Code Integration
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">
                    Setiap produk PlastiKo dilengkapi dengan QR Code unik yang memungkinkan:
                  </p>
                  <ul className="space-y-2 text-sm text-gray-700">
                    <li className="flex items-start">
                      <ChevronRight className="h-4 w-4 text-green-600 mr-2 mt-0.5 flex-shrink-0" />
                      Pelacakan proses daur ulang produk
                    </li>
                    <li className="flex items-start">
                      <ChevronRight className="h-4 w-4 text-green-600 mr-2 mt-0.5 flex-shrink-0" />
                      Informasi detail tentang material produk
                    </li>
                    <li className="flex items-start">
                      <ChevronRight className="h-4 w-4 text-green-600 mr-2 mt-0.5 flex-shrink-0" />
                      Panduan komposting yang tepat
                    </li>
                  </ul>
                </CardContent>
              </Card>
              
              <Card className="border-green-200">
                <CardHeader>
                  <CardTitle className="text-green-800 flex items-center">
                    <Recycle className="mr-2 h-5 w-5" />
                    Color Change Technology
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">
                    Teknologi inovatif kami menampilkan perubahan warna pada kemasan:
                  </p>
                  <ul className="space-y-2 text-sm text-gray-700">
                    <li className="flex items-start">
                      <ChevronRight className="h-4 w-4 text-green-600 mr-2 mt-0.5 flex-shrink-0" />
                      Indikator waktu degradasi produk
                    </li>
                    <li className="flex items-start">
                      <ChevronRight className="h-4 w-4 text-green-600 mr-2 mt-0.5 flex-shrink-0" />
                      Visual feedback untuk proses komposting
                    </li>
                    <li className="flex items-start">
                      <ChevronRight className="h-4 w-4 text-green-600 mr-2 mt-0.5 flex-shrink-0" />
                      Edukasi visual untuk konsumen
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="color-guide" className="mt-8">
            <ColorGuide />
          </TabsContent>
          
          <TabsContent value="guide" className="mt-8">
            <CompostingGuide />
          </TabsContent>
          
          <TabsContent value="animation" className="mt-8">
            <ColorChangeAnimation />
          </TabsContent>
          
          <TabsContent value="tracking" className="mt-8">
            <Card className="border-green-200 max-w-2xl mx-auto">
              <CardHeader className="text-center">
                <CardTitle className="text-green-800">Pelacakan Produk PlastiKo</CardTitle>
                <CardDescription>
                  Masukkan kode QR atau scan untuk melacak produk Anda
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex space-x-2">
                  <input 
                    type="text" 
                    placeholder="Masukkan kode QR..."
                    className="flex-1 px-4 py-2 border border-green-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                  <Button 
                    className="bg-green-600 hover:bg-green-700 text-white"
                    onClick={handleQRScan}
                  >
                    Track
                  </Button>
                </div>
                <div className="text-center">
                  <Button 
                    variant="outline"
                    className="border-green-600 text-green-600 hover:bg-green-50"
                    onClick={handleQRScan}
                  >
                    <Smartphone className="mr-2 h-5 w-5" />
                    Scan QR Code
                  </Button>
                </div>
                {showQRScanner && (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto"></div>
                    <p className="text-green-600 mt-4">Membuka QR Scanner...</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </section>

      {/* Stats Section */}
      <section className="bg-green-600 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <Users className="h-8 w-8 mx-auto mb-2" />
              <div className="text-3xl font-bold">10,000+</div>
              <div className="text-green-100">Pelanggan Puas</div>
            </div>
            <div>
              <Package className="h-8 w-8 mx-auto mb-2" />
              <div className="text-3xl font-bold">50+</div>
              <div className="text-green-100">Produk Variasi</div>
            </div>
            <div>
              <Recycle className="h-8 w-8 mx-auto mb-2" />
              <div className="text-3xl font-bold">100%</div>
              <div className="text-green-100">Biodegradable</div>
            </div>
            <div>
              <Globe className="h-8 w-8 mx-auto mb-2" />
              <div className="text-3xl font-bold">25+</div>
              <div className="text-green-100">Kota Terlayani</div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-green-800 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-5 gap-8">
            {/* Company Info */}
            <div className="md:col-span-2">
              <div className="flex items-center space-x-2 mb-4">
                <Leaf className="h-6 w-6" />
                <span className="text-xl font-bold">PlastiKo</span>
              </div>
              <p className="text-green-200 mb-6">
                Solusi bioplastik berkelanjutan untuk masa depan yang lebih hijau. 
                Kemasan cerdas yang dapat terurai dan mendeteksi kesegaran makanan.
              </p>
              
              {/* Social Media */}
              <div className="flex space-x-4">
                <a 
                  href="https://facebook.com/plastiko" 
                  className="w-10 h-10 bg-green-700 rounded-full flex items-center justify-center hover:bg-green-600 transition-colors"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Facebook className="h-5 w-5" />
                </a>
                <a 
                  href="https://instagram.com/plastiko" 
                  className="w-10 h-10 bg-green-700 rounded-full flex items-center justify-center hover:bg-green-600 transition-colors"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Instagram className="h-5 w-5" />
                </a>
                <a 
                  href="https://linkedin.com/company/plastiko" 
                  className="w-10 h-10 bg-green-700 rounded-full flex items-center justify-center hover:bg-green-600 transition-colors"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Linkedin className="h-5 w-5" />
                </a>
                <a 
                  href="https://twitter.com/plastiko" 
                  className="w-10 h-10 bg-green-700 rounded-full flex items-center justify-center hover:bg-green-600 transition-colors"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Twitter className="h-5 w-5" />
                </a>
              </div>
            </div>
            
            {/* Products */}
            <div>
              <h4 className="font-semibold mb-4">Produk</h4>
              <ul className="space-y-2 text-green-200">
                <li><a href="#" className="hover:text-white transition-colors">Food Container</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Shopping Bag</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Cutlery Set</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Custom Packaging</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Smart Labels</a></li>
              </ul>
            </div>
            
            {/* Company */}
            <div>
              <h4 className="font-semibold mb-4">Perusahaan</h4>
              <ul className="space-y-2 text-green-200">
                <li><a href="#" className="hover:text-white transition-colors">Tentang Kami</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Visi & Misi</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Karir</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Partner</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Blog</a></li>
              </ul>
            </div>
            
            {/* Contact */}
            <div>
              <h4 className="font-semibold mb-4">Kontak</h4>
              <div className="space-y-3 text-green-200">
                <div className="flex items-center space-x-2">
                  <Mail className="h-4 w-4" />
                  <a href="mailto:info@plastiko.id" className="hover:text-white transition-colors">
                    info@plastiko.id
                  </a>
                </div>
                <div className="flex items-center space-x-2">
                  <Phone className="h-4 w-4" />
                  <a href="tel:+622112345678" className="hover:text-white transition-colors">
                    +62 21 1234 5678
                  </a>
                </div>
                <div className="flex items-center space-x-2">
                  <Phone className="h-4 w-4" />
                  <a href="tel:+628123456789" className="hover:text-white transition-colors">
                    +62 812 3456 789
                  </a>
                </div>
                <div className="flex items-start space-x-2">
                  <MapPin className="h-4 w-4 mt-0.5" />
                  <span className="text-sm">
                    Jl. Hijau No. 123, Jakarta Selatan, DKI Jakarta 12345, Indonesia
                  </span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Important Links */}
          <div className="border-t border-green-700 mt-8 pt-8">
            <div className="grid md:grid-cols-2 gap-8 mb-6">
              <div>
                <h4 className="font-semibold mb-3">Link Penting</h4>
                <div className="flex flex-wrap gap-4">
                  <a 
                    href="#" 
                    className="text-green-200 hover:text-white transition-colors flex items-center text-sm"
                  >
                    <ExternalLink className="h-3 w-3 mr-1" />
                    Kebijakan Privasi
                  </a>
                  <a 
                    href="#" 
                    className="text-green-200 hover:text-white transition-colors flex items-center text-sm"
                  >
                    <ExternalLink className="h-3 w-3 mr-1" />
                    Syarat & Ketentuan
                  </a>
                  <a 
                    href="#" 
                    className="text-green-200 hover:text-white transition-colors flex items-center text-sm"
                  >
                    <ExternalLink className="h-3 w-3 mr-1" />
                    Kebijakan Pengembalian
                  </a>
                  <a 
                    href="#" 
                    className="text-green-200 hover:text-white transition-colors flex items-center text-sm"
                  >
                    <ExternalLink className="h-3 w-3 mr-1" />
                    Sertifikasi
                  </a>
                  <a 
                    href="#" 
                    className="text-green-200 hover:text-white transition-colors flex items-center text-sm"
                  >
                    <ExternalLink className="h-3 w-3 mr-1" />
                    FAQ
                  </a>
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold mb-3">Newsletter</h4>
                <p className="text-green-200 text-sm mb-3">
                  Dapatkan informasi terbaru tentang produk dan tips keberlanjutan
                </p>
                <div className="flex space-x-2">
                  <input 
                    type="email" 
                    placeholder="Email Anda"
                    className="px-3 py-2 bg-green-700 border border-green-600 rounded-lg text-white placeholder-green-300 focus:outline-none focus:ring-2 focus:ring-green-500 flex-1"
                  />
                  <Button className="bg-green-600 hover:bg-green-700 text-white px-4">
                    Subscribe
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="border-t border-green-700 pt-6 text-center text-green-200">
              <p className="mb-2">© 2024 PlastiKo. All rights reserved.</p>
              <p className="text-sm">
                Making the world greener, one package at a time 🌱
              </p>
            </div>
          </div>
        </div>
      </footer>
      
      {/* QR Scanner Modal */}
      {showQRScanner && (
        <QRScanner 
          onClose={() => setShowQRScanner(false)}
          onScanSuccess={handleScanSuccess}
        />
      )}
    </div>
  )
}