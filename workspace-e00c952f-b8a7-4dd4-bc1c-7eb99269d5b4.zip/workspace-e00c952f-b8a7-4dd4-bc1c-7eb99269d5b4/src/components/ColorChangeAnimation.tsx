'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Play, Pause, RotateCcw, Droplets, Sun, Leaf, Package } from 'lucide-react'
import { motion } from 'framer-motion'

export default function ColorChangeAnimation() {
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentStage, setCurrentStage] = useState(0)
  const [progress, setProgress] = useState(0)

  const stages = [
    {
      name: 'Fresh Product',
      color: 'bg-green-500',
      description: 'Produk baru dalam kondisi prima',
      duration: 2000,
      icon: <Leaf className="h-4 w-4" />
    },
    {
      name: 'Early Decomposition',
      color: 'bg-green-400',
      description: 'Mulai proses dekomposisi awal',
      duration: 2000,
      icon: <Droplets className="h-4 w-4" />
    },
    {
      name: 'Active Decomposition',
      color: 'bg-yellow-400',
      description: 'Proses dekomposisi aktif',
      duration: 2000,
      icon: <Sun className="h-4 w-4" />
    },
    {
      name: 'Advanced Decomposition',
      color: 'bg-orange-400',
      description: 'Dekomposisi lanjutan',
      duration: 2000,
      icon: <Sun className="h-4 w-4" />
    },
    {
      name: 'Fully Composted',
      color: 'bg-amber-600',
      description: 'Sepenuhnya terurai menjadi kompos',
      duration: 2000,
      icon: <Leaf className="h-4 w-4" />
    }
  ]

  useEffect(() => {
    let interval: NodeJS.Timeout
    let progressInterval: NodeJS.Timeout

    if (isPlaying) {
      progressInterval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            return 0
          }
          return prev + 2
        })
      }, 40)

      interval = setInterval(() => {
        setCurrentStage((prev) => {
          if (prev >= stages.length - 1) {
            setIsPlaying(false)
            return prev
          }
          return prev + 1
        })
        setProgress(0)
      }, stages[currentStage].duration)
    }

    return () => {
      if (interval) clearInterval(interval)
      if (progressInterval) clearInterval(progressInterval)
    }
  }, [isPlaying, currentStage, stages])

  const handlePlay = () => {
    setIsPlaying(true)
    setProgress(0)
  }

  const handlePause = () => {
    setIsPlaying(false)
  }

  const handleReset = () => {
    setIsPlaying(false)
    setCurrentStage(0)
    setProgress(0)
  }

  const currentStageData = stages[currentStage]

  return (
    <Card className="border-green-200 overflow-hidden">
      <CardHeader>
        <CardTitle className="text-green-800 flex items-center">
          <Leaf className="h-5 w-5 mr-2" />
          Animasi Perubahan Warna Kemasan
        </CardTitle>
        <CardDescription>
          Simulasi perubahan warna kemasan bioplastik selama proses dekomposisi
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Product Container Animation */}
        <div className="relative">
          <div className="flex justify-center mb-4">
            <motion.div
              className="w-32 h-32 rounded-2xl shadow-lg flex items-center justify-center transition-all duration-1000"
              style={{
                backgroundColor: isPlaying 
                  ? `hsl(${120 - (currentStage * 20)}, 70%, ${50 - (currentStage * 5)}%)`
                  : undefined
              }}
              animate={{
                backgroundColor: isPlaying 
                  ? [`hsl(120, 70%, 50%)`, `hsl(${120 - (currentStage * 20)}, 70%, ${50 - (currentStage * 5)}%)`]
                  : undefined
              }}
              transition={{ duration: 1.5, ease: "easeInOut" }}
            >
              <div className="text-white text-center">
                <Package className="h-12 w-12 mx-auto mb-2" />
                <p className="text-xs font-semibold">PlastiKo</p>
              </div>
            </motion.div>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
            <motion.div
              className="bg-green-600 h-2 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.1 }}
            />
          </div>

          {/* Stage Information */}
          <div className="text-center mb-4">
            <motion.div
              key={currentStage}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Badge variant="secondary" className="bg-green-100 text-green-800 mb-2">
                {currentStageData.icon}
                <span className="ml-2">{currentStageData.name}</span>
              </Badge>
              <p className="text-sm text-gray-600">{currentStageData.description}</p>
            </motion.div>
          </div>

          {/* Timeline */}
          <div className="flex justify-between items-center mb-6">
            {stages.map((stage, index) => (
              <div key={index} className="flex flex-col items-center">
                <motion.div
                  className={`w-3 h-3 rounded-full ${
                    index <= currentStage ? 'bg-green-600' : 'bg-gray-300'
                  }`}
                  animate={{
                    scale: index === currentStage && isPlaying ? [1, 1.2, 1] : 1
                  }}
                  transition={{ duration: 1, repeat: isPlaying ? Infinity : 0 }}
                />
                <p className="text-xs text-gray-500 mt-1 text-center">
                  {stage.name.split(' ')[0]}
                </p>
              </div>
            ))}
          </div>

          {/* Control Buttons */}
          <div className="flex justify-center space-x-4">
            {!isPlaying ? (
              <Button 
                onClick={handlePlay}
                className="bg-green-600 hover:bg-green-700 text-white"
                disabled={currentStage >= stages.length - 1}
              >
                <Play className="h-4 w-4 mr-2" />
                Mainkan Animasi
              </Button>
            ) : (
              <Button 
                onClick={handlePause}
                variant="outline"
                className="border-red-600 text-red-600 hover:bg-red-50"
              >
                <Pause className="h-4 w-4 mr-2" />
                Pause
              </Button>
            )}
            <Button 
              onClick={handleReset}
              variant="outline"
              className="border-green-600 text-green-600 hover:bg-green-50"
            >
              <RotateCcw className="h-4 w-4 mr-2" />
              Reset
            </Button>
          </div>
        </div>

        {/* Information Cards */}
        <div className="grid md:grid-cols-2 gap-4 mt-6">
          <Card className="border-green-100">
            <CardContent className="p-4">
              <h4 className="font-semibold text-green-800 mb-2">Teknologi Warna</h4>
              <p className="text-sm text-gray-600">
                Kemasan PlastiKo menggunakan pewarna alami yang berubah warna 
                seiring waktu untuk menunjukkan tingkat dekomposisi.
              </p>
            </CardContent>
          </Card>
          <Card className="border-green-100">
            <CardContent className="p-4">
              <h4 className="font-semibold text-green-800 mb-2">Manfaat Visual</h4>
              <p className="text-sm text-gray-600">
                Perubahan warna membantu konsumen memahami kapan produk 
                telah terurai sepenuhnya dan siap untuk kompos.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Time Information */}
        <div className="bg-green-50 rounded-lg p-4">
          <h4 className="font-semibold text-green-800 mb-2">Estimasi Waktu Dekomposisi</h4>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-2 text-sm">
            <div className="text-center">
              <p className="font-medium text-green-700">0-1 bulan</p>
              <p className="text-gray-600">Hijau Terang</p>
            </div>
            <div className="text-center">
              <p className="font-medium text-green-700">1-2 bulan</p>
              <p className="text-gray-600">Hijau Muda</p>
            </div>
            <div className="text-center">
              <p className="font-medium text-green-700">2-3 bulan</p>
              <p className="text-gray-600">Kuning</p>
            </div>
            <div className="text-center">
              <p className="font-medium text-green-700">3-4 bulan</p>
              <p className="text-gray-600">Oranye</p>
            </div>
            <div className="text-center">
              <p className="font-medium text-green-700">4-6 bulan</p>
              <p className="text-gray-600">Coklat Tua</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}