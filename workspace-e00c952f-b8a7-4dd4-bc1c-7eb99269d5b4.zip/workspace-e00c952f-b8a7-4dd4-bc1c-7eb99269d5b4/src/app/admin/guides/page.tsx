'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { 
  BookOpen, 
  Plus, 
  Edit, 
  Trash2, 
  Eye, 
  EyeOff,
  Image as ImageIcon,
  Video,
  Save,
  X,
  MoveUp,
  MoveDown
} from 'lucide-react'
import { motion } from 'framer-motion'

interface Guide {
  id: string
  title: string
  type: string
  content: string
  imageUrl?: string
  videoUrl?: string
  order: number
  isActive: boolean
  createdAt: string
  updatedAt: string
}

const guideTypes = [
  { value: 'color', label: 'Panduan Warna' },
  { value: 'composting', label: 'Instruksi Komposting' },
  { value: 'material', label: 'Transparansi Bahan' },
  { value: 'safety', label: 'Keamanan Pangan' }
]

export default function ManageGuides() {
  const [guides, setGuides] = useState<Guide[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editingGuide, setEditingGuide] = useState<Guide | null>(null)
  const [filter, setFilter] = useState('all')

  // Form state
  const [formData, setFormData] = useState({
    title: '',
    type: '',
    content: '',
    imageUrl: '',
    videoUrl: '',
    order: 0,
    isActive: true
  })

  useEffect(() => {
    fetchGuides()
  }, [])

  const fetchGuides = async () => {
    try {
      const response = await fetch('/api/guides')
      const data = await response.json()
      setGuides(data)
    } catch (error) {
      console.error('Error fetching guides:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const url = editingGuide ? `/api/guides/${editingGuide.id}` : '/api/guides'
      const method = editingGuide ? 'PUT' : 'POST'
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        await fetchGuides()
        setShowForm(false)
        setEditingGuide(null)
        resetForm()
      }
    } catch (error) {
      console.error('Error saving guide:', error)
    }
  }

  const handleEdit = (guide: Guide) => {
    setEditingGuide(guide)
    setFormData({
      title: guide.title,
      type: guide.type,
      content: guide.content,
      imageUrl: guide.imageUrl || '',
      videoUrl: guide.videoUrl || '',
      order: guide.order,
      isActive: guide.isActive
    })
    setShowForm(true)
  }

  const handleDelete = async (id: string) => {
    if (confirm('Apakah Anda yakin ingin menghapus panduan ini?')) {
      try {
        const response = await fetch(`/api/guides/${id}`, {
          method: 'DELETE',
        })
        if (response.ok) {
          await fetchGuides()
        }
      } catch (error) {
        console.error('Error deleting guide:', error)
      }
    }
  }

  const toggleActive = async (guide: Guide) => {
    try {
      const response = await fetch(`/api/guides/${guide.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...guide,
          isActive: !guide.isActive
        }),
      })
      if (response.ok) {
        await fetchGuides()
      }
    } catch (error) {
      console.error('Error toggling guide status:', error)
    }
  }

  const moveGuide = async (guide: Guide, direction: 'up' | 'down') => {
    const newOrder = direction === 'up' ? guide.order - 1 : guide.order + 1
    try {
      const response = await fetch(`/api/guides/${guide.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...guide,
          order: newOrder
        }),
      })
      if (response.ok) {
        await fetchGuides()
      }
    } catch (error) {
      console.error('Error moving guide:', error)
    }
  }

  const resetForm = () => {
    setFormData({
      title: '',
      type: '',
      content: '',
      imageUrl: '',
      videoUrl: '',
      order: 0,
      isActive: true
    })
  }

  const filteredGuides = guides.filter(guide => 
    filter === 'all' || guide.type === filter
  )

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-green-800">Kelola Panduan</h2>
          <p className="text-gray-600">Kelola konten panduan terkait perubahan warna, komposting, dan transparansi bahan</p>
        </div>
        <Button 
          onClick={() => setShowForm(true)}
          className="bg-green-600 hover:bg-green-700"
        >
          <Plus className="h-4 w-4 mr-2" />
          Tambah Panduan
        </Button>
      </div>

      {/* Filter */}
      <div className="flex items-center space-x-4">
        <Label htmlFor="filter">Filter:</Label>
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Semua Panduan</SelectItem>
            {guideTypes.map(type => (
              <SelectItem key={type.value} value={type.value}>
                {type.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Form */}
      {showForm && (
        <Card className="border-green-200">
          <CardHeader>
            <CardTitle className="text-green-800">
              {editingGuide ? 'Edit Panduan' : 'Tambah Panduan Baru'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="title">Judul Panduan</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({...formData, title: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="type">Tipe Panduan</Label>
                  <Select value={formData.type} onValueChange={(value) => setFormData({...formData, type: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih tipe" />
                    </SelectTrigger>
                    <SelectContent>
                      {guideTypes.map(type => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="content">Konten</Label>
                <Textarea
                  id="content"
                  value={formData.content}
                  onChange={(e) => setFormData({...formData, content: e.target.value})}
                  rows={6}
                  required
                />
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="imageUrl">URL Gambar (opsional)</Label>
                  <Input
                    id="imageUrl"
                    value={formData.imageUrl}
                    onChange={(e) => setFormData({...formData, imageUrl: e.target.value})}
                    placeholder="https://example.com/image.jpg"
                  />
                </div>
                <div>
                  <Label htmlFor="videoUrl">URL Video (opsional)</Label>
                  <Input
                    id="videoUrl"
                    value={formData.videoUrl}
                    onChange={(e) => setFormData({...formData, videoUrl: e.target.value})}
                    placeholder="https://example.com/video.mp4"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="order">Urutan</Label>
                  <Input
                    id="order"
                    type="number"
                    value={formData.order}
                    onChange={(e) => setFormData({...formData, order: parseInt(e.target.value)})}
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="isActive"
                    checked={formData.isActive}
                    onCheckedChange={(checked) => setFormData({...formData, isActive: checked})}
                  />
                  <Label htmlFor="isActive">Aktif</Label>
                </div>
              </div>

              <div className="flex space-x-2">
                <Button type="submit" className="bg-green-600 hover:bg-green-700">
                  <Save className="h-4 w-4 mr-2" />
                  {editingGuide ? 'Update' : 'Simpan'}
                </Button>
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={() => {
                    setShowForm(false)
                    setEditingGuide(null)
                    resetForm()
                  }}
                >
                  <X className="h-4 w-4 mr-2" />
                  Batal
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Guides List */}
      <div className="space-y-4">
        {filteredGuides.map((guide, index) => (
          <motion.div
            key={guide.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <Card className={`border-l-4 ${
              guide.isActive ? 'border-green-500' : 'border-gray-300'
            }`}>
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h3 className="text-lg font-semibold text-green-800">{guide.title}</h3>
                      <Badge variant="secondary" className="bg-green-100 text-green-800">
                        {guideTypes.find(t => t.value === guide.type)?.label}
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        Urutan: {guide.order}
                      </Badge>
                    </div>
                    <p className="text-gray-600 mb-3 line-clamp-2">{guide.content}</p>
                    <div className="flex items-center space-x-4 text-sm text-gray-500">
                      {guide.imageUrl && (
                        <div className="flex items-center space-x-1">
                          <ImageIcon className="h-4 w-4" />
                          <span>Gambar</span>
                        </div>
                      )}
                      {guide.videoUrl && (
                        <div className="flex items-center space-x-1">
                          <Video className="h-4 w-4" />
                          <span>Video</span>
                        </div>
                      )}
                      <span>Dibuat: {new Date(guide.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2 ml-4">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => toggleActive(guide)}
                      className={guide.isActive ? 'text-green-600' : 'text-gray-400'}
                    >
                      {guide.isActive ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => moveGuide(guide, 'up')}
                      disabled={index === 0}
                    >
                      <MoveUp className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => moveGuide(guide, 'down')}
                      disabled={index === filteredGuides.length - 1}
                    >
                      <MoveDown className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleEdit(guide)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDelete(guide.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {filteredGuides.length === 0 && (
        <div className="text-center py-12">
          <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-600 mb-2">Belum ada panduan</h3>
          <p className="text-gray-500 mb-4">Mulai dengan menambahkan panduan pertama Anda</p>
          <Button 
            onClick={() => setShowForm(true)}
            className="bg-green-600 hover:bg-green-700"
          >
            <Plus className="h-4 w-4 mr-2" />
            Tambah Panduan
          </Button>
        </div>
      )}
    </div>
  )
}