'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { 
  Sidebar, 
  SidebarContent, 
  SidebarHeader, 
  SidebarMenu, 
  SidebarMenuItem, 
  SidebarMenuButton,
  SidebarProvider,
  SidebarTrigger
} from '@/components/ui/sidebar'
import { 
  BarChart3, 
  Package, 
  Users, 
  QrCode, 
  Settings, 
  Home,
  Plus,
  Edit,
  Trash2,
  TrendingUp,
  ShoppingCart,
  ScanLine,
  BookOpen,
  List,
  Eye,
  AlertCircle,
  CheckCircle,
  Clock,
  Recycle
} from 'lucide-react'
import { motion } from 'framer-motion'
import Link from 'next/link'

interface Product {
  id: string
  name: string
  description: string
  price: number
  material: string
  advantages: string
  image?: string
  createdAt: string
}

interface User {
  id: string
  name: string
  email: string
  phone?: string
  address?: string
  createdAt: string
  qrScans: any[]
}

interface QRScan {
  id: string
  productId: string
  userId?: string
  scanDate: string
  location?: string
  scannedData: string
  phLevel?: number
  freshnessStatus?: string
  colorIndicator?: string
  guideAccessed?: string
  createdAt: string
  product: Product
  user?: User
}

interface Statistics {
  totalQRScans: number
  completedComposting: number
  guideAccessStats: Array<{ guideAccessed: string; _count: { guideAccessed: number } }>
  freshnessStats: Array<{ freshnessStatus: string; _count: { freshnessStatus: number } }>
  colorStats: Array<{ colorIndicator: string; _count: { colorIndicator: number } }>
  monthlyScans: Array<{ month: string; count: number }>
  topProducts: Array<{ productId: string; _count: { productId: number }; product: Product }>
}

export default function AdminDashboard() {
  const [products, setProducts] = useState<Product[]>([])
  const [users, setUsers] = useState<User[]>([])
  const [qrScans, setQrScans] = useState<QRScan[]>([])
  const [statistics, setStatistics] = useState<Statistics | null>(null)
  const [activeTab, setActiveTab] = useState('dashboard')
  const [isLoading, setIsLoading] = useState(true)
  const [showProductForm, setShowProductForm] = useState(false)
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)

  // Form state
  const [productForm, setProductForm] = useState({
    name: '',
    description: '',
    price: '',
    material: '',
    advantages: '',
    image: ''
  })

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      const [productsRes, usersRes, qrScansRes, statsRes] = await Promise.all([
        fetch('/api/products'),
        fetch('/api/users'),
        fetch('/api/qr-scans'),
        fetch('/api/statistics')
      ])

      const productsData = await productsRes.json()
      const usersData = await usersRes.json()
      const qrScansData = await qrScansRes.json()
      const statsData = await statsRes.json()

      setProducts(productsData)
      setUsers(usersData)
      setQrScans(qrScansData)
      setStatistics(statsData)
    } catch (error) {
      console.error('Error fetching data:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const url = editingProduct ? `/api/products/${editingProduct.id}` : '/api/products'
      const method = editingProduct ? 'PUT' : 'POST'
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(productForm),
      })

      if (response.ok) {
        await fetchData()
        setShowProductForm(false)
        setEditingProduct(null)
        setProductForm({
          name: '',
          description: '',
          price: '',
          material: '',
          advantages: '',
          image: ''
        })
      }
    } catch (error) {
      console.error('Error saving product:', error)
    }
  }

  const handleEditProduct = (product: Product) => {
    setEditingProduct(product)
    setProductForm({
      name: product.name,
      description: product.description,
      price: product.price.toString(),
      material: product.material,
      advantages: product.advantages,
      image: product.image || ''
    })
    setShowProductForm(true)
  }

  const handleDeleteProduct = async (id: string) => {
    if (confirm('Apakah Anda yakin ingin menghapus produk ini?')) {
      try {
        const response = await fetch(`/api/products/${id}`, {
          method: 'DELETE',
        })
        if (response.ok) {
          await fetchData()
        }
      } catch (error) {
        console.error('Error deleting product:', error)
      }
    }
  }

  const stats = {
    totalProducts: products.length,
    totalUsers: users.length,
    totalScans: qrScans.length,
    totalRevenue: products.reduce((sum, p) => sum + p.price, 0)
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    )
  }

  return (
    <SidebarProvider>
      <div className="flex min-h-screen bg-gray-50">
        <Sidebar className="border-r border-green-200">
          <SidebarHeader className="bg-green-600 text-white p-4">
            <div className="flex items-center space-x-2">
              <Package className="h-6 w-6" />
              <span className="font-bold">PKMS Admin</span>
            </div>
          </SidebarHeader>
          <SidebarContent className="p-4">
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton 
                  onClick={() => setActiveTab('dashboard')}
                  className={activeTab === 'dashboard' ? 'bg-green-100 text-green-800' : ''}
                >
                  <Home className="h-4 w-4" />
                  <span>Dashboard</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton 
                  onClick={() => setActiveTab('products')}
                  className={activeTab === 'products' ? 'bg-green-100 text-green-800' : ''}
                >
                  <Package className="h-4 w-4" />
                  <span>Produk</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton 
                  onClick={() => setActiveTab('users')}
                  className={activeTab === 'users' ? 'bg-green-100 text-green-800' : ''}
                >
                  <Users className="h-4 w-4" />
                  <span>Pengguna</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton 
                  onClick={() => setActiveTab('qr-scans')}
                  className={activeTab === 'qr-scans' ? 'bg-green-100 text-green-800' : ''}
                >
                  <ScanLine className="h-4 w-4" />
                  <span>QR Scans</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton asChild>
                  <Link href="/admin/guides" className="flex items-center space-x-2">
                    <BookOpen className="h-4 w-4" />
                    <span>Kelola Panduan</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton asChild>
                  <Link href="/admin/qr-scans" className="flex items-center space-x-2">
                    <List className="h-4 w-4" />
                    <span>Daftar QR Scans</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton 
                  onClick={() => setActiveTab('analytics')}
                  className={activeTab === 'analytics' ? 'bg-green-100 text-green-800' : ''}
                >
                  <BarChart3 className="h-4 w-4" />
                  <span>Analitik</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton 
                  onClick={() => setActiveTab('settings')}
                  className={activeTab === 'settings' ? 'bg-green-100 text-green-800' : ''}
                >
                  <Settings className="h-4 w-4" />
                  <span>Pengaturan</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarContent>
        </Sidebar>

        <div className="flex-1">
          <header className="bg-white shadow-sm border-b border-green-200 p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <SidebarTrigger />
                <h1 className="text-2xl font-bold text-green-800">
                  {activeTab === 'dashboard' && 'Ringkasan Statistik'}
                  {activeTab === 'products' && 'Manajemen Produk'}
                  {activeTab === 'users' && 'Manajemen Pengguna'}
                  {activeTab === 'qr-scans' && 'QR Scan Tracking'}
                  {activeTab === 'analytics' && 'Analitik'}
                  {activeTab === 'settings' && 'Pengaturan'}
                </h1>
              </div>
              <Button variant="outline" className="border-green-600 text-green-600">
                Kembali ke Situs
              </Button>
            </div>
          </header>

          <main className="p-6">
            {activeTab === 'dashboard' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                  <Card className="border-green-200">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Total Produk</CardTitle>
                      <Package className="h-4 w-4 text-green-600" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-green-800">{products.length}</div>
                      <p className="text-xs text-green-600">Produk tersedia</p>
                    </CardContent>
                  </Card>
                  <Card className="border-green-200">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">QR Scans</CardTitle>
                      <ScanLine className="h-4 w-4 text-green-600" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-green-800">{statistics?.totalQRScans || 0}</div>
                      <p className="text-xs text-green-600">Total pemindaian</p>
                    </CardContent>
                  </Card>
                  <Card className="border-green-200">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Kemasan Terurai</CardTitle>
                      <Recycle className="h-4 w-4 text-green-600" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-green-800">{statistics?.completedComposting || 0}</div>
                      <p className="text-xs text-green-600">Berhasil dikomposting</p>
                    </CardContent>
                  </Card>
                  <Card className="border-green-200">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Total Pengguna</CardTitle>
                      <Users className="h-4 w-4 text-green-600" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-green-800">{users.length}</div>
                      <p className="text-xs text-green-600">Pengguna terdaftar</p>
                    </CardContent>
                  </Card>
                </div>

                {/* User Interaction Analysis */}
                <div className="grid md:grid-cols-3 gap-6 mb-8">
                  <Card className="border-green-200">
                    <CardHeader>
                      <CardTitle className="text-green-800 flex items-center">
                        <Eye className="h-5 w-5 mr-2" />
                        Analisis Interaksi Pengguna
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <h4 className="font-semibold text-green-700">Guide Paling Banyak Diakses</h4>
                        {statistics?.guideAccessStats.map((stat, index) => (
                          <div key={index} className="flex justify-between items-center">
                            <span className="text-sm text-gray-600">
                              {stat.guideAccessed === 'color' ? 'Panduan Warna' :
                               stat.guideAccessed === 'composting' ? 'Instruksi Komposting' :
                               stat.guideAccessed === 'material' ? 'Transparansi Bahan' : stat.guideAccessed}
                            </span>
                            <Badge variant="secondary" className="bg-green-100 text-green-800">
                              {stat._count.guideAccessed}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-green-200">
                    <CardHeader>
                      <CardTitle className="text-green-800 flex items-center">
                        <CheckCircle className="h-5 w-5 mr-2" />
                        Distribusi Kesegaran
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {statistics?.freshnessStats.map((stat, index) => (
                          <div key={index} className="flex justify-between items-center">
                            <span className="text-sm text-gray-600">{stat.freshnessStatus}</span>
                            <div className="flex items-center space-x-2">
                              <div className="w-16 bg-gray-200 rounded-full h-2">
                                <div 
                                  className="bg-green-600 h-2 rounded-full" 
                                  style={{ 
                                    width: `${(stat._count.freshnessStatus / (statistics?.totalQRScans || 1)) * 100}%` 
                                  }}
                                ></div>
                              </div>
                              <span className="text-sm font-medium">{stat._count.freshnessStatus}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-green-200">
                    <CardHeader>
                      <CardTitle className="text-green-800 flex items-center">
                        <AlertCircle className="h-5 w-5 mr-2" />
                        Distribusi Warna
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {statistics?.colorStats.map((stat, index) => (
                          <div key={index} className="flex justify-between items-center">
                            <span className="text-sm text-gray-600">{stat.colorIndicator}</span>
                            <div className="flex items-center space-x-2">
                              <div className={`w-4 h-4 rounded-full ${
                                stat.colorIndicator === 'Hijau Tua' ? 'bg-green-600' :
                                stat.colorIndicator === 'Hijau Muda' ? 'bg-green-400' :
                                stat.colorIndicator === 'Kuning' ? 'bg-yellow-400' :
                                stat.colorIndicator === 'Oranye' ? 'bg-orange-400' :
                                stat.colorIndicator === 'Merah' ? 'bg-red-500' : 'bg-gray-400'
                              }`}></div>
                              <span className="text-sm font-medium">{stat._count.colorIndicator}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <Card className="border-green-200">
                    <CardHeader>
                      <CardTitle className="text-green-800">Produk Terbaru</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {products.slice(0, 5).map((product) => (
                          <div key={product.id} className="flex items-center justify-between">
                            <div>
                              <p className="font-medium text-green-800">{product.name}</p>
                              <p className="text-sm text-gray-600">{product.material}</p>
                            </div>
                            <Badge variant="secondary" className="bg-green-100 text-green-800">
                              Rp {product.price.toLocaleString()}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-green-200">
                    <CardHeader>
                      <CardTitle className="text-green-800">QR Scans Terbaru</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {qrScans.slice(0, 5).map((scan) => (
                          <div key={scan.id} className="flex items-center justify-between">
                            <div>
                              <p className="font-medium text-green-800">{scan.product.name}</p>
                              <p className="text-sm text-gray-600">{scan.location || 'Unknown location'}</p>
                            </div>
                            <Badge variant="secondary" className="bg-green-100 text-green-800">
                              {new Date(scan.scanDate).toLocaleDateString()}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </motion.div>
            )}

            {activeTab === 'products' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-semibold text-green-800">Manajemen Produk</h2>
                  <Button 
                    onClick={() => setShowProductForm(true)}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Tambah Produk
                  </Button>
                </div>

                {showProductForm && (
                  <Card className="mb-6 border-green-200">
                    <CardHeader>
                      <CardTitle className="text-green-800">
                        {editingProduct ? 'Edit Produk' : 'Tambah Produk Baru'}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <form onSubmit={handleProductSubmit} className="space-y-4">
                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="name">Nama Produk</Label>
                            <Input
                              id="name"
                              value={productForm.name}
                              onChange={(e) => setProductForm({...productForm, name: e.target.value})}
                              required
                            />
                          </div>
                          <div>
                            <Label htmlFor="price">Harga</Label>
                            <Input
                              id="price"
                              type="number"
                              value={productForm.price}
                              onChange={(e) => setProductForm({...productForm, price: e.target.value})}
                              required
                            />
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="material">Material</Label>
                          <Input
                            id="material"
                            value={productForm.material}
                            onChange={(e) => setProductForm({...productForm, material: e.target.value})}
                            required
                          />
                        </div>
                        <div>
                          <Label htmlFor="description">Deskripsi</Label>
                          <Textarea
                            id="description"
                            value={productForm.description}
                            onChange={(e) => setProductForm({...productForm, description: e.target.value})}
                            required
                          />
                        </div>
                        <div>
                          <Label htmlFor="advantages">Keunggulan</Label>
                          <Textarea
                            id="advantages"
                            value={productForm.advantages}
                            onChange={(e) => setProductForm({...productForm, advantages: e.target.value})}
                            required
                          />
                        </div>
                        <div>
                          <Label htmlFor="image">URL Gambar (opsional)</Label>
                          <Input
                            id="image"
                            value={productForm.image}
                            onChange={(e) => setProductForm({...productForm, image: e.target.value})}
                          />
                        </div>
                        <div className="flex space-x-2">
                          <Button type="submit" className="bg-green-600 hover:bg-green-700">
                            {editingProduct ? 'Update' : 'Simpan'}
                          </Button>
                          <Button 
                            type="button" 
                            variant="outline"
                            onClick={() => {
                              setShowProductForm(false)
                              setEditingProduct(null)
                              setProductForm({
                                name: '',
                                description: '',
                                price: '',
                                material: '',
                                advantages: '',
                                image: ''
                              })
                            }}
                          >
                            Batal
                          </Button>
                        </div>
                      </form>
                    </CardContent>
                  </Card>
                )}

                <div className="grid gap-4">
                  {products.map((product) => (
                    <Card key={product.id} className="border-green-200">
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <h3 className="text-lg font-semibold text-green-800">{product.name}</h3>
                            <p className="text-gray-600 mt-1">{product.description}</p>
                            <div className="flex items-center space-x-4 mt-2">
                              <Badge variant="secondary" className="bg-green-100 text-green-800">
                                {product.material}
                              </Badge>
                              <span className="text-green-700 font-semibold">
                                Rp {product.price.toLocaleString()}
                              </span>
                            </div>
                          </div>
                          <div className="flex space-x-2">
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => handleEditProduct(product)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => handleDeleteProduct(product.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </motion.div>
            )}

            {activeTab === 'users' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <h2 className="text-xl font-semibold text-green-800 mb-6">Manajemen Pengguna</h2>
                <div className="grid gap-4">
                  {users.map((user) => (
                    <Card key={user.id} className="border-green-200">
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <h3 className="text-lg font-semibold text-green-800">{user.name}</h3>
                            <p className="text-gray-600">{user.email}</p>
                            {user.phone && <p className="text-sm text-gray-500">{user.phone}</p>}
                            {user.address && <p className="text-sm text-gray-500">{user.address}</p>}
                          </div>
                          <div className="text-right">
                            <Badge variant="secondary" className="bg-green-100 text-green-800">
                              {user.qrScans.length} QR Scans
                            </Badge>
                            <p className="text-sm text-gray-500 mt-1">
                              Bergabung: {new Date(user.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </motion.div>
            )}

            {activeTab === 'qr-scans' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <h2 className="text-xl font-semibold text-green-800 mb-6">QR Scan Tracking</h2>
                <div className="grid gap-4">
                  {qrScans.map((scan) => (
                    <Card key={scan.id} className="border-green-200">
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <h3 className="text-lg font-semibold text-green-800">{scan.product.name}</h3>
                            <p className="text-gray-600">Di-scan oleh: {scan.user?.name || 'Anonymous'}</p>
                            {scan.location && <p className="text-sm text-gray-500">Lokasi: {scan.location}</p>}
                          </div>
                          <div className="text-right">
                            <Badge variant="secondary" className="bg-green-100 text-green-800">
                              {new Date(scan.scanDate).toLocaleDateString()}
                            </Badge>
                            <p className="text-sm text-gray-500 mt-1">
                              {new Date(scan.scanDate).toLocaleTimeString()}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </motion.div>
            )}

            {activeTab === 'analytics' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <h2 className="text-xl font-semibold text-green-800 mb-6">Analitik</h2>
                <div className="grid md:grid-cols-2 gap-6">
                  <Card className="border-green-200">
                    <CardHeader>
                      <CardTitle className="text-green-800">Produk Populer</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {products.slice(0, 5).map((product) => {
                          const scanCount = qrScans.filter(scan => scan.productId === product.id).length
                          return (
                            <div key={product.id} className="flex items-center justify-between">
                              <div>
                                <p className="font-medium text-green-800">{product.name}</p>
                                <p className="text-sm text-gray-600">{scanCount} scans</p>
                              </div>
                              <div className="w-24 bg-green-100 rounded-full h-2">
                                <div 
                                  className="bg-green-600 h-2 rounded-full" 
                                  style={{ width: `${(scanCount / Math.max(...qrScans.map(s => qrScans.filter(scan => scan.productId === s.productId).length))) * 100}%` }}
                                ></div>
                              </div>
                            </div>
                          )
                        })}
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-green-200">
                    <CardHeader>
                      <CardTitle className="text-green-800">Lokasi Scan</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {Array.from(new Set(qrScans.map(scan => scan.location).filter(Boolean))).map((location, index) => {
                          const locationCount = qrScans.filter(scan => scan.location === location).length
                          return (
                            <div key={index} className="flex items-center justify-between">
                              <div>
                                <p className="font-medium text-green-800">{location}</p>
                                <p className="text-sm text-gray-600">{locationCount} scans</p>
                              </div>
                              <Badge variant="secondary" className="bg-green-100 text-green-800">
                                #{index + 1}
                              </Badge>
                            </div>
                          )
                        })}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </motion.div>
            )}

            {activeTab === 'settings' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <h2 className="text-xl font-semibold text-green-800 mb-6">Pengaturan</h2>
                <Card className="border-green-200">
                  <CardHeader>
                    <CardTitle className="text-green-800">Pengaturan Sistem</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="company-name">Nama Perusahaan</Label>
                      <Input id="company-name" defaultValue="PlastiKo" />
                    </div>
                    <div>
                      <Label htmlFor="email">Email Admin</Label>
                      <Input id="email" type="email" defaultValue="admin@plastiko.id" />
                    </div>
                    <div>
                      <Label htmlFor="phone">Telepon</Label>
                      <Input id="phone" defaultValue="+62 21 1234 5678" />
                    </div>
                    <Button className="bg-green-600 hover:bg-green-700">
                      Simpan Pengaturan
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </main>
        </div>
      </div>
    </SidebarProvider>
  )
}