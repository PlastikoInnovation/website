import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    // Get total QR scans
    const totalQRScans = await db.qRScan.count()

    // Get unique users
    const uniqueUsers = await db.qRScan.groupBy({
      by: ['userId'],
      where: {
        userId: {
          not: null
        }
      }
    })

    // Get completed composting reports
    const completedComposting = await db.compostingReport.count({
      where: { status: 'completed' }
    })

    // Get user interaction analysis
    const guideAccessStats = await db.qRScan.groupBy({
      by: ['guideAccessed'],
      _count: {
        guideAccessed: true
      },
      where: {
        guideAccessed: {
          not: null
        }
      }
    })

    // Get freshness status distribution
    const freshnessStats = await db.qRScan.groupBy({
      by: ['freshnessStatus'],
      _count: {
        freshnessStatus: true
      },
      where: {
        freshnessStatus: {
          not: null
        }
      }
    })

    // Get color indicator distribution
    const colorStats = await db.qRScan.groupBy({
      by: ['colorIndicator'],
      _count: {
        colorIndicator: true
      },
      where: {
        colorIndicator: {
          not: null
        }
      }
    })

    // Get monthly scan trends
    const monthlyScans = await db.$queryRaw`
      SELECT 
        strftime('%Y-%m', scanDate) as month,
        COUNT(*) as count
      FROM QRScan 
      WHERE scanDate >= date('now', '-12 months')
      GROUP BY strftime('%Y-%m', scanDate)
      ORDER BY month DESC
      LIMIT 12
    ` as Array<{ month: string; count: number }>

    // Get top products scanned
    const topProducts = await db.qRScan.groupBy({
      by: ['productId'],
      _count: {
        productId: true
      },
      orderBy: {
        _count: {
          productId: 'desc'
        }
      },
      take: 5
    })

    // Get product details for top products
    const productDetails = await db.product.findMany({
      where: {
        id: {
          in: topProducts.map(p => p.productId)
        }
      }
    })

    const topProductsWithDetails = topProducts.map(product => ({
      ...product,
      product: productDetails.find(p => p.id === product.productId)
    }))

    // Calculate average pH level
    const phLevels = await db.qRScan.findMany({
      where: {
        phLevel: {
          not: null
        }
      },
      select: {
        phLevel: true
      }
    })

    const averagePH = phLevels.length > 0 
      ? phLevels.reduce((sum, scan) => sum + (scan.phLevel || 0), 0) / phLevels.length 
      : 0

    // Get top guide
    const topGuide = guideAccessStats.length > 0 
      ? guideAccessStats.reduce((prev, current) => 
          prev._count.guideAccessed > current._count.guideAccessed ? prev : current
        ).guideAccessed
      : null

    const statistics = {
      totalQRScans,
      uniqueUsers: uniqueUsers.length,
      completedComposting,
      averagePH,
      topGuide,
      guideAccessStats,
      freshnessStats,
      colorStats,
      monthlyScans: monthlyScans.reverse(),
      topProducts: topProductsWithDetails
    }

    return NextResponse.json(statistics)
  } catch (error) {
    console.error('Error fetching statistics:', error)
    return NextResponse.json(
      { error: 'Failed to fetch statistics' },
      { status: 500 }
    )
  }
}