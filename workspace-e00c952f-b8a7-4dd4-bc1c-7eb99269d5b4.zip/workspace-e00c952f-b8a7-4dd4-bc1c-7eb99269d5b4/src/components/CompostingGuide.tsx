'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { 
  Recycle, 
  Leaf, 
  Droplets, 
  Sun, 
  CheckCircle, 
  Clock, 
  Thermometer,
  Home,
  Building,
  AlertCircle,
  Info
} from 'lucide-react'
import { motion } from 'framer-motion'

interface CompostingStep {
  id: number
  title: string
  description: string
  duration: string
  icon: React.ReactNode
  tips: string[]
  warning?: string
}

const compostingSteps: CompostingStep[] = [
  {
    id: 1,
    title: 'Persiapan Kemasan',
    description: 'Bersihkan kemasan dari sisa makanan dan potong menjadi bagian lebih kecil untuk mempercepat proses dekomposisi.',
    duration: '5 menit',
    icon: <Recycle className="h-6 w-6" />,
    tips: [
      'Buang sisa makanan ke tempat sampah organik',
      'Potong kemasan menjadi 2-4 bagian',
      'Pastikan tidak ada bahan non-biodegradable menempel'
    ]
  },
  {
    id: 2,
    title: 'Campur dengan Material Organik',
    description: 'Campur potongan kemasan PlastiKo dengan material organik lain seperti sisa sayuran, buah-buahan, atau daun kering.',
    duration: '10 menit',
    icon: <Leaf className="h-6 w-6" />,
    tips: [
      'Perbandingan ideal: 1 bagian PlastiKo : 3 bagian organik',
      'Tambahkan material coklat (daun kering, kertas) untuk keseimbangan',
      'Aduk hingga tercampur merata'
    ]
  },
  {
    id: 3,
    title: 'Atur Kelembaban',
    description: 'Pastikan campuran memiliki kelembaban yang tepat, seperti spons yang diperas - tidak terlalu basah atau kering.',
    duration: '5 menit',
    icon: <Droplets className="h-6 w-6" />,
    tips: [
      'Tambahkan air sedikit demi sedikit jika terlalu kering',
      'Tambahkan material kering jika terlalu basah',
      'Test: genggam campuran, seharusnya tidak menetes air'
    ],
    warning: 'Terlalu banyak air dapat memperlambat proses komposting'
  },
  {
    id: 4,
    title: 'Proses Komposting',
    description: 'Biarkan campuran terdekomposisi secara alami dengan suhu dan kelembaban yang tepat.',
    duration: '3-6 bulan',
    icon: <Thermometer className="h-6 w-6" />,
    tips: [
      'Suhu ideal: 50-60°C untuk komposting aktif',
      'Aduk setiap 1-2 minggu untuk sirkulasi udara',
      'Jaga kelembaban selama proses berlangsung'
    ]
  },
  {
    id: 5,
    title: 'Pemeriksaan Berkala',
    description: 'Periksa proses dekomposisi secara berkala dan amati perubahan warna kemasan.',
    duration: 'Setiap minggu',
    icon: <Clock className="h-6 w-6" />,
    tips: [
      'Warna akan berubah dari hijau ke coklat',
      'Kemasan akan menjadi lebih lunak dan rapuh',
      'Aroma tidak berbau menyengat jika proses benar'
    ]
  },
  {
    id: 6,
    title: 'Kompos Siap',
    description: 'Setelah 3-6 bulan, kemasan PlastiKo akan sepenuhnya terurai menjadi kompos yang siap digunakan.',
    duration: 'Selesai',
    icon: <CheckCircle className="h-6 w-6" />,
    tips: [
      'Kompos akan berwarna coklat gelap dan beraroma tanah',
      'Dapat digunakan untuk pupuk tanaman',
      'Tidak ada sisa kemasan yang terlihat'
    ]
  }
]

const disposalMethods = [
  {
    title: 'Komposting Rumah',
    icon: <Home className="h-8 w-8" />,
    description: 'Cocok untuk penggunaan rumah tangga dengan skala kecil.',
    pros: [
      'Mudah dilakukan di rumah',
      'Hasil kompos bisa digunakan sendiri',
      'Ramah lingkungan',
      'Biaya minimal'
    ],
    cons: [
      'Membutuhkan space',
      'Proses lebih lambat',
      'Perlu perhatian khusus'
    ],
    timeEstimate: '3-6 bulan'
  },
  {
    title: 'Komposting Industri',
    icon: <Building className="h-8 w-8" />,
    description: 'Layanan komposting profesional dengan fasilitas lengkap.',
    pros: [
      'Proses lebih cepat',
      'Hasil lebih konsisten',
      'Tidak perlu repot',
      'Kapasitas besar'
    ],
    cons: [
      'Biaya lebih tinggi',
      'Perlu transportasi',
      'Tersedia di area tertentu'
    ],
    timeEstimate: '1-3 bulan'
  }
]

export default function CompostingGuide() {
  const [selectedMethod, setSelectedMethod] = useState<'home' | 'industrial'>('home')
  const [currentStep, setCurrentStep] = useState(1)

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-3xl font-bold text-green-800 mb-4">
          Panduan Komposting & Pembuangan
        </h2>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Ikuti langkah-langkah berikut untuk membuang kemasan PlastiKo dengan benar 
          melalui proses komposting yang ramah lingkungan.
        </p>
      </div>

      {/* Disposal Method Selection */}
      <Card className="border-green-200">
        <CardHeader>
          <CardTitle className="text-green-800">Pilih Metode Pembuangan</CardTitle>
          <CardDescription>
            Pilih metode yang paling sesuai dengan kebutuhan dan kondisi Anda
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            {disposalMethods.map((method) => (
              <motion.div
                key={method.title}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Card 
                  className={`cursor-pointer transition-all duration-300 ${
                    selectedMethod === (method.title.includes('Rumah') ? 'home' : 'industrial')
                      ? 'border-green-500 bg-green-50' 
                      : 'border-gray-200 hover:border-green-300'
                  }`}
                  onClick={() => setSelectedMethod(method.title.includes('Rumah') ? 'home' : 'industrial')}
                >
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-4 mb-4">
                      <div className="text-green-600">
                        {method.icon}
                      </div>
                      <div>
                        <h3 className="font-semibold text-green-800">{method.title}</h3>
                        <Badge variant="secondary" className="bg-green-100 text-green-800 mt-1">
                          {method.timeEstimate}
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600 mb-4">{method.description}</p>
                    <div className="space-y-2">
                      <div className="text-sm">
                        <span className="font-medium text-green-700">Kelebihan:</span>
                        <ul className="mt-1 space-y-1">
                          {method.pros.map((pro, index) => (
                            <li key={index} className="text-xs text-gray-600 flex items-center">
                              <CheckCircle className="h-3 w-3 text-green-500 mr-1" />
                              {pro}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div className="text-sm">
                        <span className="font-medium text-orange-700">Kekurangan:</span>
                        <ul className="mt-1 space-y-1">
                          {method.cons.map((con, index) => (
                            <li key={index} className="text-xs text-gray-600 flex items-center">
                              <AlertCircle className="h-3 w-3 text-orange-500 mr-1" />
                              {con}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Step-by-Step Guide */}
      <Card className="border-green-200">
        <CardHeader>
          <CardTitle className="text-green-800">Langkah-langkah Komposting</CardTitle>
          <CardDescription>
            Ikuti 6 langkah mudah untuk mengkomposting kemasan PlastiKo
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {compostingSteps.map((step, index) => (
              <motion.div
                key={step.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <Card className={`border-l-4 transition-all duration-300 ${
                  currentStep === step.id 
                    ? 'border-l-green-500 bg-green-50' 
                    : 'border-l-gray-300 hover:border-l-green-400'
                }`}>
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <div className="flex-shrink-0">
                        <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                          currentStep === step.id ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-600'
                        }`}>
                          {step.icon}
                        </div>
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-semibold text-green-800">
                            Langkah {step.id}: {step.title}
                          </h3>
                          <div className="flex items-center space-x-2">
                            <Clock className="h-4 w-4 text-gray-500" />
                            <span className="text-sm text-gray-500">{step.duration}</span>
                          </div>
                        </div>
                        <p className="text-gray-600 mb-3">{step.description}</p>
                        
                        <div className="space-y-2">
                          <div className="text-sm">
                            <span className="font-medium text-green-700">Tips:</span>
                            <ul className="mt-1 space-y-1">
                              {step.tips.map((tip, tipIndex) => (
                                <li key={tipIndex} className="text-xs text-gray-600 flex items-start">
                                  <CheckCircle className="h-3 w-3 text-green-500 mr-1 mt-0.5 flex-shrink-0" />
                                  {tip}
                                </li>
                              ))}
                            </ul>
                          </div>
                          
                          {step.warning && (
                            <div className="bg-orange-50 border border-orange-200 rounded-lg p-3">
                              <div className="flex items-start space-x-2">
                                <AlertCircle className="h-4 w-4 text-orange-500 mt-0.5 flex-shrink-0" />
                                <p className="text-xs text-orange-700">{step.warning}</p>
                              </div>
                            </div>
                          )}
                        </div>

                        <div className="mt-4 flex space-x-2">
                          {step.id > 1 && (
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => setCurrentStep(step.id - 1)}
                            >
                              Sebelumnya
                            </Button>
                          )}
                          {step.id < compostingSteps.length && (
                            <Button 
                              size="sm"
                              className="bg-green-600 hover:bg-green-700 text-white"
                              onClick={() => setCurrentStep(step.id + 1)}
                            >
                              Selanjutnya
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Important Information */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card className="border-green-200">
          <CardHeader>
            <CardTitle className="text-green-800 flex items-center">
              <Info className="h-5 w-5 mr-2" />
              Informasi Penting
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-start space-x-2">
              <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
              <p className="text-sm text-gray-600">
                Kemasan PlastiKo 100% biodegradable dan tidak meninggalkan residu berbahaya.
              </p>
            </div>
            <div className="flex items-start space-x-2">
              <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
              <p className="text-sm text-gray-600">
                Hasil kompos dapat digunakan untuk pupuk tanaman hias atau sayuran.
              </p>
            </div>
            <div className="flex items-start space-x-2">
              <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
              <p className="text-sm text-gray-600">
                Proses komposting membantu mengurangi limbah plastik hingga 100%.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-green-200">
          <CardHeader>
            <CardTitle className="text-green-800 flex items-center">
              <Sun className="h-5 w-5 mr-2" />
              Tips Tambahan
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-start space-x-2">
              <Leaf className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
              <p className="text-sm text-gray-600">
                Tambahkan cacing tanah untuk mempercepat proses komposting.
              </p>
            </div>
            <div className="flex items-start space-x-2">
              <Leaf className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
              <p className="text-sm text-gray-600">
                Hindari menambahkan daging atau produk hewani ke kompos.
              </p>
            </div>
            <div className="flex items-start space-x-2">
              <Leaf className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
              <p className="text-sm text-gray-600">
                Simpan komposter di tempat yang teduh dan memiliki sirkulasi udara baik.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}