import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { emailService } from '@/lib/email'

export async function GET() {
  try {
    const qrScans = await db.qRScan.findMany({
      include: {
        product: true,
        user: true
      },
      orderBy: {
        scanDate: 'desc'
      }
    })
    
    return NextResponse.json(qrScans)
  } catch (error) {
    console.error('Error fetching QR scans:', error)
    return NextResponse.json(
      { error: 'Failed to fetch QR scans' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { productId, userId, location, scannedData } = body

    if (!productId || !scannedData) {
      return NextResponse.json(
        { error: 'Product ID and scanned data are required' },
        { status: 400 }
      )
    }

    const qrScan = await db.qRScan.create({
      data: {
        productId,
        userId: userId || null,
        location: location || null,
        scannedData: JSON.stringify(scannedData),
        phLevel: scannedData.phLevel || null,
        freshnessStatus: scannedData.freshnessStatus || null,
        colorIndicator: scannedData.colorIndicator || null,
        guideAccessed: scannedData.guideAccessed || null
      },
      include: {
        product: true,
        user: true
      }
    })

    // Send notification to admin
    await emailService.sendAdminNotification(
      'New QR Scan Detected',
      `Product "${qrScan.product.name}" has been scanned${qrScan.user ? ` by ${qrScan.user.name}` : ''}${qrScan.location ? ` at ${qrScan.location}` : ''}.`
    )

    // Send notification to user if available
    if (qrScan.user) {
      await emailService.sendQRScanNotification(
        qrScan.user.email,
        qrScan.product.name,
        qrScan.scanDate
      )
    }

    return NextResponse.json(qrScan, { status: 201 })
  } catch (error) {
    console.error('Error creating QR scan:', error)
    return NextResponse.json(
      { error: 'Failed to create QR scan' },
      { status: 500 }
    )
  }
}