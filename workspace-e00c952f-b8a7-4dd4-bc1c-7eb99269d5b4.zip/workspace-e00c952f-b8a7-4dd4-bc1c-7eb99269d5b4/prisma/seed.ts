import { db } from '@/lib/db'

async function seed() {
  try {
    // Create sample products
    const products = await Promise.all([
      db.product.create({
        data: {
          name: 'PlastiKo Food Container',
          description: 'Wadah makanan biodegradable yang ramah lingkungan',
          price: 25000,
          material: 'PLA (Polylactic Acid)',
          advantages: '100% biodegradable, food safe, compostable',
          image: '/api/placeholder/300/200'
        }
      }),
      db.product.create({
        data: {
          name: 'PlastiKo Shopping Bag',
          description: 'Tas belanja dari bahan terbarukan',
          price: 15000,
          material: 'Corn Starch Bioplastic',
          advantages: 'Water resistant, durable, biodegradable',
          image: '/api/placeholder/300/200'
        }
      }),
      db.product.create({
        data: {
          name: 'PlastiKo Cutlery Set',
          description: 'Set peralatan makan sekali pakai yang ramah lingkungan',
          price: 35000,
          material: 'CPLA (Crystallized PLA)',
          advantages: 'Heat resistant, sturdy, compostable',
          image: '/api/placeholder/300/200'
        }
      })
    ])

    // Create sample users
    const users = await Promise.all([
      db.user.create({
        data: {
          name: 'John Doe',
          email: 'john@example.com',
          phone: '+62 812 3456 7890',
          address: 'Jakarta, Indonesia'
        }
      }),
      db.user.create({
        data: {
          name: 'Jane Smith',
          email: 'jane@example.com',
          phone: '+62 813 4567 8901',
          address: 'Bandung, Indonesia'
        }
      })
    ])

    // Create sample QR scans
    await Promise.all([
      db.qRScan.create({
        data: {
          productId: products[0].id,
          userId: users[0].id,
          location: 'Jakarta',
          scannedData: JSON.stringify({
            colorGuide: 'Green to Brown',
            compostingInstructions: 'Place in compost bin for 3-6 months',
            materialTransparency: '100% PLA from corn starch'
          })
        }
      }),
      db.qRScan.create({
        data: {
          productId: products[1].id,
          userId: users[1].id,
          location: 'Bandung',
          scannedData: JSON.stringify({
            colorGuide: 'Light Green to Clear',
            compostingInstructions: 'Industrial composting recommended',
            materialTransparency: 'Corn starch based bioplastic'
          })
        }
      })
    ])

    console.log('Database seeded successfully!')
  } catch (error) {
    console.error('Error seeding database:', error)
  }
}

seed()